import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.services.orchestrator_service import AnalysisOrchestrator, AnalysisState

class TestLangGraphWorkflow(unittest.TestCase):
    def setUp(self):
        # Mock database manager
        self.mock_db = MagicMock()
        self.mock_db.insert_analysis.return_value = 'test_analysis_id'

        # Mock all AI services
        with patch('backend.services.orchestrator_service.EmotionAnalysisService'), \
             patch('backend.services.orchestrator_service.SentimentAnalysisService'), \
             patch('backend.services.orchestrator_service.CognitiveDistortionService'), \
             patch('backend.services.orchestrator_service.RiskAssessmentService'), \
             patch('backend.services.orchestrator_service.DisorderPatternService'), \
             patch('backend.services.orchestrator_service.VisionAnalysisService'), \
             patch('backend.services.orchestrator_service.RecommendationService'), \
             patch('backend.services.orchestrator_service.SummaryService'), \
             patch('backend.services.orchestrator_service.CrisisResourceService'):

            self.orchestrator = AnalysisOrchestrator(self.mock_db)

    def test_preprocess_node(self):
        state = AnalysisState(
            input_text="test",
            input_image_path=None,
            user_id="test_user",
            raw_emotions=[],
            sentiment_data={},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={},
            disorder_patterns=[],
            vision_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={},
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        result = self.orchestrator.preprocess_node(state)

        self.assertIn('timestamp', result)
        self.assertIsInstance(result['timestamp'], datetime)

    def test_emotion_node(self):
        # Mock emotion service
        mock_emotion = MagicMock()
        mock_emotion.emotion = "sadness"
        mock_emotion.score = 0.85
        mock_emotion.intensity = "strong"
        mock_emotion.explanation = "test explanation"

        self.orchestrator.emotion_service.analyze = Mock(return_value=[mock_emotion])

        state = AnalysisState(
            input_text="I feel sad",
            input_image_path=None,
            user_id="test_user",
            raw_emotions=[],
            sentiment_data={},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={},
            disorder_patterns=[],
            vision_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={},
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        result = self.orchestrator.emotion_node(state)

        self.assertIn('raw_emotions', result)
        self.assertGreater(len(result['raw_emotions']), 0)
        self.assertEqual(result['raw_emotions'][0]['emotion'], 'sadness')

    def test_risk_node(self):
        # Mock risk assessment
        from backend.models.analysis_models import RiskAssessment

        mock_risk = RiskAssessment(
            overall_risk_level="moderate",
            risk_score=0.5,
            self_harm_indicators=["hopelessness"],
            protective_factors=["support"],
            explanation="test explanation",
            recommended_action="test action"
        )

        self.orchestrator.risk_service.analyze = Mock(return_value=mock_risk)

        state = AnalysisState(
            input_text="I feel hopeless",
            input_image_path=None,
            user_id="test_user",
            raw_emotions=[],
            sentiment_data={},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={},
            disorder_patterns=[],
            vision_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={},
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        result = self.orchestrator.risk_node(state)

        self.assertIn('risk_assessment', result)
        self.assertEqual(result['risk_assessment']['overall_risk_level'], 'moderate')

    def test_persistence_node(self):
        state = AnalysisState(
            input_text="test text",
            input_image_path=None,
            user_id="test_user",
            raw_emotions=[],
            sentiment_data={'sentiment_intensity': 50.0},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={
                'overall_risk_level': 'minimal',
                'risk_score': 0.1,
                'self_harm_indicators': [],
                'protective_factors': [],
                'explanation': 'test',
                'recommended_action': 'test'
            },
            disorder_patterns=[],
            vision_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={
                'primary_emotions': [],
                'emotional_state': 'neutral',
                'cognitive_patterns': [],
                'stress_level': 'low',
                'mental_state_description': 'test',
                'key_insights': []
            },
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        result = self.orchestrator.persistence_node(state)

        # Verify DB insert was called
        self.mock_db.insert_analysis.assert_called_once()

        # Verify analysis_result was created
        self.assertIsNotNone(result['analysis_result'])
        self.assertEqual(result['analysis_result'].analysis_id, 'test_analysis_id')

if __name__ == '__main__':
    unittest.main()
