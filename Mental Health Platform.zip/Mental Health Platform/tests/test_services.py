import unittest
from unittest.mock import Mock, patch
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.services.emotion_service import EmotionAnalysisService
from backend.services.sentiment_service import SentimentAnalysisService
from backend.services.cognitive_service import CognitiveDistortionService
from backend.services.risk_service import RiskAssessmentService
from backend.services.disorder_service import DisorderPatternService

class TestEmotionService(unittest.TestCase):
    @patch('backend.services.emotion_service.pipeline')
    def test_emotion_analysis(self, mock_pipeline):
        # Mock the pipeline response
        mock_pipeline.return_value = Mock(return_value=[[
            {'label': 'sadness', 'score': 0.85},
            {'label': 'fear', 'score': 0.65},
            {'label': 'joy', 'score': 0.15}
        ]])

        service = EmotionAnalysisService()
        service.classifier = mock_pipeline.return_value

        result = service.analyze("I feel so sad and worried about everything")

        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)
        self.assertEqual(result[0].emotion, 'sadness')
        self.assertEqual(result[0].score, 0.85)
        self.assertIn(result[0].intensity, ['mild', 'moderate', 'strong'])

class TestSentimentService(unittest.TestCase):
    @patch('backend.services.sentiment_service.pipeline')
    def test_sentiment_analysis(self, mock_pipeline):
        mock_pipeline.return_value = Mock(return_value=[[
            {'label': 'negative', 'score': 0.7},
            {'label': 'positive', 'score': 0.2},
            {'label': 'neutral', 'score': 0.1}
        ]])

        service = SentimentAnalysisService()
        service.classifier = mock_pipeline.return_value

        result = service.analyze("Everything feels hopeless")

        self.assertIsInstance(result, dict)
        self.assertIn('sentiment_intensity', result)
        self.assertIn('polarity', result)
        self.assertIn('stress_level', result)
        self.assertEqual(result['polarity'], 'negative')

class TestCognitiveService(unittest.TestCase):
    def test_detect_all_or_nothing(self):
        service = CognitiveDistortionService()

        text = "I always fail at everything. Nobody ever understands me."
        result = service.analyze(text)

        self.assertIsInstance(result, list)
        distortion_types = [d.distortion_type for d in result]
        self.assertIn("All-or-Nothing Thinking", distortion_types)

    def test_detect_catastrophizing(self):
        service = CognitiveDistortionService()

        text = "This is a complete disaster. Everything is ruined."
        result = service.analyze(text)

        distortion_types = [d.distortion_type for d in result]
        self.assertIn("Catastrophizing", distortion_types)

    def test_detect_rumination(self):
        service = CognitiveDistortionService()

        text = "I can't stop thinking about it. The thoughts keep going over and over in my mind."
        result = service.detect_rumination(text)

        self.assertTrue(result['rumination_detected'])
        self.assertGreater(result['rumination_score'], 0)

class TestRiskService(unittest.TestCase):
    def test_high_risk_detection(self):
        service = RiskAssessmentService()

        text = "I want to end my life. I can't go on anymore."
        emotion_data = [{'emotion': 'sadness', 'score': 0.9}]

        result = service.analyze(text, emotion_data)

        self.assertEqual(result.overall_risk_level, 'elevated')
        self.assertGreater(result.risk_score, 0.6)
        self.assertGreater(len(result.self_harm_indicators), 0)

    def test_low_risk_detection(self):
        service = RiskAssessmentService()

        text = "I'm feeling a bit down today but I have hope things will improve."
        emotion_data = [{'emotion': 'sadness', 'score': 0.4}]

        result = service.analyze(text, emotion_data)

        self.assertIn(result.overall_risk_level, ['minimal', 'low'])
        self.assertLess(result.risk_score, 0.5)

    def test_protective_factors(self):
        service = RiskAssessmentService()

        text = "I'm struggling but my family cares about me and I'm in therapy."
        emotion_data = []

        result = service.analyze(text, emotion_data)

        self.assertGreater(len(result.protective_factors), 0)

class TestDisorderService(unittest.TestCase):
    def test_anxiety_pattern_detection(self):
        service = DisorderPatternService()

        text = "I'm so anxious all the time. I can't stop worrying about everything. What if something bad happens?"
        emotion_data = [{'emotion': 'fear', 'score': 0.8}]

        result = service.analyze(text, emotion_data)

        pattern_names = [p.pattern_name for p in result]
        self.assertTrue(any('anxiety' in name.lower() for name in pattern_names))

    def test_depression_pattern_detection(self):
        service = DisorderPatternService()

        text = "I feel so empty and numb. I have no energy or motivation to do anything. I can't enjoy anything anymore."
        emotion_data = [{'emotion': 'sadness', 'score': 0.85}]

        result = service.analyze(text, emotion_data)

        pattern_names = [p.pattern_name for p in result]
        self.assertTrue(any('depress' in name.lower() for name in pattern_names))

    def test_ocd_pattern_detection(self):
        service = DisorderPatternService()

        text = "I have intrusive thoughts that won't go away. I keep checking and rechecking things over and over."
        emotion_data = []

        result = service.analyze(text, emotion_data)

        pattern_names = [p.pattern_name for p in result]
        self.assertTrue(any('ocd' in name.lower() for name in pattern_names))

if __name__ == '__main__':
    unittest.main()
