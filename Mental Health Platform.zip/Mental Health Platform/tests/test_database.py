import unittest
from unittest.mock import Mock, patch, MagicMock
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.config.database import DatabaseManager

class TestDatabaseManager(unittest.TestCase):
    @patch('backend.config.database.MongoClient')
    def setUp(self, mock_mongo_client):
        # Mock MongoDB client
        self.mock_client = MagicMock()
        mock_mongo_client.return_value = self.mock_client

        # Mock database
        self.mock_db = MagicMock()
        self.mock_client.__getitem__.return_value = self.mock_db

        # Mock admin command (for ping)
        self.mock_client.admin.command.return_value = True

        self.db_manager = DatabaseManager('mongodb://localhost:27017/', 'test_db')

    def test_connection(self):
        # Test that connection was attempted
        self.assertIsNotNone(self.db_manager.client)
        self.assertIsNotNone(self.db_manager.db)

    def test_get_collection(self):
        collection = self.db_manager.get_collection('analysis')
        self.mock_db.__getitem__.assert_called_with('analysis')

    def test_insert_analysis(self):
        # Mock collection
        mock_collection = MagicMock()
        mock_result = MagicMock()
        mock_result.inserted_id = '507f1f77bcf86cd799439011'
        mock_collection.insert_one.return_value = mock_result

        self.mock_db.__getitem__.return_value = mock_collection

        analysis_data = {
            'user_id': 'test_user',
            'emotions': [],
            'sentiment_intensity': 50.0
        }

        result_id = self.db_manager.insert_analysis(analysis_data)

        # Verify insert was called
        mock_collection.insert_one.assert_called_once()

        # Verify returned ID
        self.assertEqual(result_id, '507f1f77bcf86cd799439011')

        # Verify timestamps were added
        call_args = mock_collection.insert_one.call_args[0][0]
        self.assertIn('created_at', call_args)
        self.assertIn('updated_at', call_args)

    @patch('backend.config.database.ObjectId')
    def test_get_analysis_by_id(self, mock_object_id):
        # Mock collection
        mock_collection = MagicMock()
        mock_result = {
            '_id': 'mock_object_id',
            'user_id': 'test_user',
            'emotions': []
        }
        mock_collection.find_one.return_value = mock_result

        self.mock_db.__getitem__.return_value = mock_collection

        result = self.db_manager.get_analysis_by_id('507f1f77bcf86cd799439011')

        # Verify find_one was called
        mock_collection.find_one.assert_called_once()

        # Verify result
        self.assertIsNotNone(result)
        self.assertEqual(result['user_id'], 'test_user')

    def test_get_user_history(self):
        # Mock collection
        mock_collection = MagicMock()

        # Mock cursor
        mock_cursor = MagicMock()
        mock_cursor.sort.return_value = mock_cursor
        mock_cursor.limit.return_value = [
            {'_id': '1', 'user_id': 'test_user'},
            {'_id': '2', 'user_id': 'test_user'}
        ]

        mock_collection.find.return_value = mock_cursor

        self.mock_db.__getitem__.return_value = mock_collection

        results = self.db_manager.get_user_history('test_user', limit=20)

        # Verify query
        mock_collection.find.assert_called_once_with({'user_id': 'test_user'})

        # Verify results
        self.assertEqual(len(results), 2)

    @patch('backend.config.database.ObjectId')
    def test_update_analysis(self, mock_object_id):
        # Mock collection
        mock_collection = MagicMock()
        mock_result = MagicMock()
        mock_result.modified_count = 1
        mock_collection.update_one.return_value = mock_result

        self.mock_db.__getitem__.return_value = mock_collection

        update_data = {'sentiment_intensity': 75.0}

        result = self.db_manager.update_analysis('507f1f77bcf86cd799439011', update_data)

        # Verify update was called
        mock_collection.update_one.assert_called_once()

        # Verify result
        self.assertTrue(result)

if __name__ == '__main__':
    unittest.main()
