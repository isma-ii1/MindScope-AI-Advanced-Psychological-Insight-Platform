import unittest
from unittest.mock import Mock, patch, MagicMock
import sys
import os
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.app import create_app

class TestAPIEndpoints(unittest.TestCase):
    def setUp(self):
        # Create test app
        self.app = create_app()
        self.app.config['TESTING'] = True

        # Mock database manager
        self.app.db_manager = MagicMock()

        self.client = self.app.test_client()

    def test_health_ping(self):
        response = self.client.get('/api/health/ping')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertEqual(data['status'], 'ok')

    def test_health_db(self):
        # Mock successful DB connection
        self.app.db_manager.client.admin.command.return_value = True

        response = self.client.get('/api/health/db')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertEqual(data['status'], 'ok')
        self.assertEqual(data['database'], 'connected')

    @patch('backend.controllers.analysis_controller.AnalysisOrchestrator')
    def test_text_analysis_endpoint(self, mock_orchestrator):
        # Mock orchestrator
        mock_instance = MagicMock()
        mock_instance.analyze_text.return_value = {
            'analysis_id': '123',
            'emotions': [],
            'sentiment_intensity': 50.0
        }
        mock_orchestrator.return_value = mock_instance

        response = self.client.post(
            '/api/analysis/text',
            json={'text': 'I feel anxious', 'user_id': 'test_user'},
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('analysis_id', data)

    @patch('backend.controllers.analysis_controller.AnalysisOrchestrator')
    def test_text_analysis_empty_text(self, mock_orchestrator):
        response = self.client.post(
            '/api/analysis/text',
            json={'text': '', 'user_id': 'test_user'},
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 400)

    @patch('backend.controllers.analysis_controller.AnalysisOrchestrator')
    def test_text_analysis_no_text(self, mock_orchestrator):
        response = self.client.post(
            '/api/analysis/text',
            json={'user_id': 'test_user'},
            content_type='application/json'
        )

        self.assertEqual(response.status_code, 400)

    def test_get_analysis_by_id(self):
        # Mock DB response
        self.app.db_manager.get_analysis_by_id.return_value = {
            '_id': '123',
            'user_id': 'test_user',
            'emotions': []
        }

        response = self.client.get('/api/analysis/123')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertEqual(data['_id'], '123')

    def test_get_analysis_not_found(self):
        self.app.db_manager.get_analysis_by_id.return_value = None

        response = self.client.get('/api/analysis/nonexistent')
        self.assertEqual(response.status_code, 404)

    def test_get_user_history(self):
        self.app.db_manager.get_user_history.return_value = [
            {'_id': '1', 'user_id': 'test_user'},
            {'_id': '2', 'user_id': 'test_user'}
        ]

        response = self.client.get('/api/analysis/history/test_user')
        self.assertEqual(response.status_code, 200)

        data = json.loads(response.data)
        self.assertEqual(len(data['history']), 2)
        self.assertEqual(data['count'], 2)

if __name__ == '__main__':
    unittest.main()
