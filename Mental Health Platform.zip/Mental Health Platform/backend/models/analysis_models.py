from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional
from datetime import datetime

@dataclass
class EmotionScore:
    emotion: str
    score: float
    intensity: str
    explanation: str

@dataclass
class CognitiveDistortion:
    distortion_type: str
    confidence: float
    evidence: str
    reframe_suggestion: str

@dataclass
class RiskAssessment:
    overall_risk_level: str
    risk_score: float
    self_harm_indicators: List[str]
    protective_factors: List[str]
    explanation: str
    recommended_action: str

@dataclass
class DisorderPattern:
    pattern_name: str
    confidence: float
    indicators: List[str]
    explanation: str

@dataclass
class Recommendation:
    recommendation_type: str
    title: str
    description: str
    why_helpful: str
    target_pattern: str

@dataclass
class GroundingTechnique:
    technique_name: str
    description: str
    steps: List[str]
    when_to_use: str

@dataclass
class VisionAnalysis:
    detected_emotions: List[str]
    facial_expression: Optional[str]
    scene_interpretation: str
    symbolic_cues: List[str]
    distress_indicators: List[str]
    psychological_interpretation: str

@dataclass
class PsychologicalSummary:
    primary_emotions: List[str]
    emotional_state: str
    cognitive_patterns: List[str]
    stress_level: str
    mental_state_description: str
    key_insights: List[str]

@dataclass
class AnalysisResult:
    analysis_id: Optional[str] = None
    user_id: str = 'anonymous'
    input_text: Optional[str] = None
    input_image_metadata: Optional[Dict] = None
    emotions: List[EmotionScore] = field(default_factory=list)
    sentiment_intensity: float = 0.0
    cognitive_distortions: List[CognitiveDistortion] = field(default_factory=list)
    risk_assessment: Optional[RiskAssessment] = None
    disorder_patterns: List[DisorderPattern] = field(default_factory=list)
    recommendations: List[Recommendation] = field(default_factory=list)
    grounding_techniques: List[GroundingTechnique] = field(default_factory=list)
    vision_analysis: Optional[VisionAnalysis] = None
    psychological_summary: Optional[PsychologicalSummary] = None
    created_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict:
        result = asdict(self)
        result['created_at'] = self.created_at.isoformat()
        return result
