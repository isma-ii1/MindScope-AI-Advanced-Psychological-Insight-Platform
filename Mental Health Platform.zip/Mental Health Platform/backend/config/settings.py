import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # MongoDB
    MONGODB_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
    MONGODB_DB = os.getenv('MONGODB_DB', 'mental_health_db')

    # Hugging Face Models
    HF_MODEL_EMOTION = os.getenv('HF_MODEL_EMOTION', 'j-hartmann/emotion-english-distilroberta-base')
    HF_MODEL_SENTIMENT = os.getenv('HF_MODEL_SENTIMENT', 'cardiffnlp/twitter-roberta-base-sentiment-latest')
    HF_MODEL_VISION = os.getenv('HF_MODEL_VISION', 'google/vit-base-patch16-224')
    HF_MODEL_LLM = os.getenv('HF_MODEL_LLM', 'mistralai/Mistral-7B-Instruct-v0.2')

    # FAISS
    FAISS_INDEX_PATH = os.getenv('FAISS_INDEX_PATH', './data/faiss_index')

    # Flask
    FLASK_ENV = os.getenv('FLASK_ENV', 'development')
    FLASK_PORT = int(os.getenv('FLASK_PORT', 5000))

    # Risk thresholds
    RISK_THRESHOLD_LOW = 0.3
    RISK_THRESHOLD_MEDIUM = 0.6
    RISK_THRESHOLD_HIGH = 0.8

    # Safety keywords
    CRISIS_KEYWORDS = [
        'suicide', 'kill myself', 'end my life', 'want to die',
        'harm myself', 'cut myself', 'overdose', 'jump off'
    ]

settings = Settings()
