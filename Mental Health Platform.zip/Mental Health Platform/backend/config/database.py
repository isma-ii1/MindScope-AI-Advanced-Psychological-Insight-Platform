from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from datetime import datetime
from typing import Dict, List, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, uri: str, db_name: str):
        self.uri = uri
        self.db_name = db_name
        self.client = None
        self.db = None
        self._connect()

    def _connect(self):
        try:
            self.client = MongoClient(
                self.uri,
                serverSelectionTimeoutMS=5000,
                connectTimeoutMS=5000
            )
            self.client.admin.command('ping')
            self.db = self.client[self.db_name]
            logger.info(f"Connected to MongoDB: {self.db_name}")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            raise

    def get_collection(self, collection_name: str):
        return self.db[collection_name]

    def insert_analysis(self, analysis_data: Dict) -> str:
        collection = self.get_collection('analysis')
        analysis_data['created_at'] = datetime.utcnow()
        analysis_data['updated_at'] = datetime.utcnow()
        result = collection.insert_one(analysis_data)
        return str(result.inserted_id)

    def get_analysis_by_id(self, analysis_id: str) -> Optional[Dict]:
        collection = self.get_collection('analysis')
        from bson.objectid import ObjectId
        try:
            result = collection.find_one({'_id': ObjectId(analysis_id)})
            if result:
                result['_id'] = str(result['_id'])
            return result
        except Exception as e:
            logger.error(f"Error fetching analysis: {e}")
            return None

    def get_user_history(self, user_id: str, limit: int = 20) -> List[Dict]:
        collection = self.get_collection('analysis')
        results = collection.find(
            {'user_id': user_id}
        ).sort('created_at', -1).limit(limit)

        history = []
        for result in results:
            result['_id'] = str(result['_id'])
            history.append(result)
        return history

    def update_analysis(self, analysis_id: str, update_data: Dict) -> bool:
        collection = self.get_collection('analysis')
        from bson.objectid import ObjectId
        try:
            update_data['updated_at'] = datetime.utcnow()
            result = collection.update_one(
                {'_id': ObjectId(analysis_id)},
                {'$set': update_data}
            )
            return result.modified_count > 0
        except Exception as e:
            logger.error(f"Error updating analysis: {e}")
            return False

    def close(self):
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")
