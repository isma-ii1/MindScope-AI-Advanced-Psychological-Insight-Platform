from flask import Flask, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os

from backend.config.database import DatabaseManager
from backend.controllers.analysis_controller import analysis_bp
from backend.controllers.health_controller import health_bp

load_dotenv()

def create_app():
    app = Flask(__name__)
    # Enable CORS for all origins (development mode)
    CORS(app, resources={
        r"/api/*": {
            "origins": "*",
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"],
            "supports_credentials": False
        }
    })

    app.config['MONGODB_URI'] = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
    app.config['MONGODB_DB'] = os.getenv('MONGODB_DB', 'mental_health_db')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

    # Initialize database
    db_manager = DatabaseManager(
        uri=app.config['MONGODB_URI'],
        db_name=app.config['MONGODB_DB']
    )
    app.db_manager = db_manager

    # Register blueprints
    app.register_blueprint(health_bp, url_prefix='/api/health')
    app.register_blueprint(analysis_bp, url_prefix='/api/analysis')

    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Resource not found'}), 404

    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({'error': 'Internal server error', 'message': str(error)}), 500

    return app

if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv('FLASK_PORT', 5000))
    # Use threaded=True to handle multiple requests
    # Use 0.0.0.0 to bind to all interfaces for network access
    app.run(host='0.0.0.0', port=port, debug=True, threaded=True, use_reloader=False)
