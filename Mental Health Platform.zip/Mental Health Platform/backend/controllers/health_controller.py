from flask import Blueprint, jsonify, current_app

health_bp = Blueprint('health', __name__)

@health_bp.route('/ping', methods=['GET'])
def ping():
    return jsonify({'status': 'ok', 'message': 'MindScope AI is running'}), 200

@health_bp.route('/db', methods=['GET'])
def check_db():
    try:
        db_manager = current_app.db_manager
        db_manager.client.admin.command('ping')
        return jsonify({'status': 'ok', 'database': 'connected'}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'database': 'disconnected', 'error': str(e)}), 500
