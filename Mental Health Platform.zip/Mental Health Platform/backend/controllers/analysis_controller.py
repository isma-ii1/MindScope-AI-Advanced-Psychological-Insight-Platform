from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
import os
import tempfile
from typing import Optional

from backend.services.orchestrator_service import AnalysisOrchestrator

analysis_bp = Blueprint('analysis', __name__)

ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}
ALLOWED_AUDIO_EXTENSIONS = {'mp3', 'wav', 'm4a', 'ogg', 'flac', 'aac'}

def allowed_image(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS

def allowed_audio(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_AUDIO_EXTENSIONS

@analysis_bp.route('/text', methods=['POST'])
def analyze_text():
    try:
        data = request.get_json()

        if not data or 'text' not in data:
            return jsonify({'error': 'No text provided'}), 400

        text = data['text']
        user_id = data.get('user_id', 'anonymous')

        if not text.strip():
            return jsonify({'error': 'Empty text provided'}), 400

        # Initialize orchestrator
        orchestrator = AnalysisOrchestrator(current_app.db_manager)

        # Run analysis
        result = orchestrator.analyze_text(text, user_id)

        return jsonify(result), 200

    except Exception as e:
        return jsonify({'error': 'Analysis failed', 'message': str(e)}), 500

@analysis_bp.route('/image', methods=['POST'])
def analyze_image():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400

        file = request.files['image']

        if file.filename == '':
            return jsonify({'error': 'No image selected'}), 400

        if not allowed_image(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400

        user_id = request.form.get('user_id', 'anonymous')
        text_context = request.form.get('text', '')

        # Save to temporary file
        filename = secure_filename(file.filename)
        temp_dir = tempfile.gettempdir()
        temp_path = os.path.join(temp_dir, filename)
        file.save(temp_path)

        try:
            # Initialize orchestrator
            orchestrator = AnalysisOrchestrator(current_app.db_manager)

            # Run analysis
            result = orchestrator.analyze_image(temp_path, user_id, text_context)

            return jsonify(result), 200
        finally:
            # Cleanup
            if os.path.exists(temp_path):
                os.remove(temp_path)

    except Exception as e:
        return jsonify({'error': 'Image analysis failed', 'message': str(e)}), 500

@analysis_bp.route('/multimodal', methods=['POST'])
def analyze_multimodal():
    try:
        text = request.form.get('text', '')
        user_id = request.form.get('user_id', 'anonymous')

        image_path: Optional[str] = None
        audio_path: Optional[str] = None

        if 'image' in request.files:
            file = request.files['image']
            if file.filename != '' and allowed_image(file.filename):
                filename = secure_filename(file.filename)
                temp_dir = tempfile.gettempdir()
                image_path = os.path.join(temp_dir, filename)
                file.save(image_path)

        if 'audio' in request.files:
            file = request.files['audio']
            if file.filename != '' and allowed_audio(file.filename):
                filename = secure_filename(file.filename)
                temp_dir = tempfile.gettempdir()
                audio_path = os.path.join(temp_dir, filename)
                file.save(audio_path)

        if not text.strip() and not image_path and not audio_path:
            return jsonify({'error': 'No text, image, or audio provided'}), 400

        try:
            orchestrator = AnalysisOrchestrator(current_app.db_manager)
            result = orchestrator.analyze_multimodal(text, image_path, audio_path, user_id)

            return jsonify(result), 200
        finally:
            if image_path and os.path.exists(image_path):
                os.remove(image_path)
            if audio_path and os.path.exists(audio_path):
                os.remove(audio_path)

    except Exception as e:
        return jsonify({'error': 'Multimodal analysis failed', 'message': str(e)}), 500

@analysis_bp.route('/history/<user_id>', methods=['GET'])
def get_history(user_id: str):
    try:
        limit = request.args.get('limit', default=20, type=int)

        db_manager = current_app.db_manager
        history = db_manager.get_user_history(user_id, limit)

        return jsonify({'user_id': user_id, 'history': history, 'count': len(history)}), 200

    except Exception as e:
        return jsonify({'error': 'Failed to fetch history', 'message': str(e)}), 500

@analysis_bp.route('/<analysis_id>', methods=['GET'])
def get_analysis(analysis_id: str):
    try:
        db_manager = current_app.db_manager
        analysis = db_manager.get_analysis_by_id(analysis_id)

        if not analysis:
            return jsonify({'error': 'Analysis not found'}), 404

        return jsonify(analysis), 200

    except Exception as e:
        return jsonify({'error': 'Failed to fetch analysis', 'message': str(e)}), 500
