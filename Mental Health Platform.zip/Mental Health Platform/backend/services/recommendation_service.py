from typing import List, Dict
import logging

from backend.models.analysis_models import Recommendation, GroundingTechnique

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RecommendationService:
    def __init__(self):
        self.book_database = self._load_book_database()
        self.routine_database = self._load_routine_database()
        self.grounding_techniques = self._load_grounding_techniques()

    def _load_book_database(self) -> Dict:
        return {
            "anxiety": [
                {
                    "title": "Dare: The New Way to End Anxiety",
                    "author": "Barry McDonagh",
                    "why_helpful": "Provides practical techniques to face anxiety rather than fight it",
                    "target_pattern": "worry loops and avoidance behaviors",
                    "tone": "practical and empowering"
                },
                {
                    "title": "The Anxiety and Phobia Workbook",
                    "author": "Edmund Bourne",
                    "why_helpful": "Comprehensive CBT-based exercises for managing anxiety",
                    "target_pattern": "generalized anxiety and panic",
                    "tone": "practical and structured"
                },
                {
                    "title": "When Panic Attacks",
                    "author": "David Burns",
                    "why_helpful": "Evidence-based techniques to break panic cycles",
                    "target_pattern": "panic attacks and catastrophic thinking",
                    "tone": "gentle and scientific"
                }
            ],
            "depression": [
                {
                    "title": "Feeling Good: The New Mood Therapy",
                    "author": "David Burns",
                    "why_helpful": "Classic CBT approach to identifying and changing negative thought patterns",
                    "target_pattern": "cognitive distortions and low mood",
                    "tone": "gentle and encouraging"
                },
                {
                    "title": "Lost Connections",
                    "author": "Johann Hari",
                    "why_helpful": "Explores root causes of depression beyond brain chemistry",
                    "target_pattern": "existential emptiness and disconnection",
                    "tone": "deep and compassionate"
                },
                {
                    "title": "The Mindful Way Through Depression",
                    "author": "Williams, Teasdale, Segal, Kabat-Zinn",
                    "why_helpful": "Combines mindfulness with depression treatment",
                    "target_pattern": "rumination and negative self-talk",
                    "tone": "gentle and meditative"
                }
            ],
            "ocd": [
                {
                    "title": "Brain Lock",
                    "author": "Jeffrey Schwartz",
                    "why_helpful": "Four-step method to break OCD cycles using neuroplasticity",
                    "target_pattern": "intrusive thoughts and compulsions",
                    "tone": "practical and scientific"
                },
                {
                    "title": "The Imp of the Mind",
                    "author": "Lee Baer",
                    "why_helpful": "Addresses unwanted intrusive thoughts with compassion",
                    "target_pattern": "disturbing intrusive thoughts",
                    "tone": "gentle and normalizing"
                }
            ],
            "trauma": [
                {
                    "title": "The Body Keeps the Score",
                    "author": "Bessel van der Kolk",
                    "why_helpful": "Explains how trauma affects the body and provides healing paths",
                    "target_pattern": "PTSD symptoms and body-based trauma",
                    "tone": "deep and validating"
                },
                {
                    "title": "Complex PTSD: From Surviving to Thriving",
                    "author": "Pete Walker",
                    "why_helpful": "Addresses childhood trauma and emotional flashbacks",
                    "target_pattern": "complex trauma and emotional dysregulation",
                    "tone": "compassionate and practical"
                }
            ],
            "personality": [
                {
                    "title": "Whole Again",
                    "author": "Jackson MacKenzie",
                    "why_helpful": "Recovery from toxic relationships and self-abandonment",
                    "target_pattern": "codependency and relationship trauma",
                    "tone": "gentle and healing"
                },
                {
                    "title": "Adult Children of Emotionally Immature Parents",
                    "author": "Lindsay Gibson",
                    "why_helpful": "Understanding and healing from childhood emotional neglect",
                    "target_pattern": "attachment issues and emotional unavailability",
                    "tone": "validating and insightful"
                }
            ],
            "general": [
                {
                    "title": "Maybe You Should Talk to Someone",
                    "author": "Lori Gottlieb",
                    "why_helpful": "Humanizes therapy and mental health struggles",
                    "target_pattern": "general emotional struggles",
                    "tone": "warm and relatable"
                },
                {
                    "title": "The Gifts of Imperfection",
                    "author": "Brené Brown",
                    "why_helpful": "Embracing vulnerability and self-compassion",
                    "target_pattern": "shame and perfectionism",
                    "tone": "warm and encouraging"
                }
            ]
        }

    def _load_routine_database(self) -> Dict:
        return {
            "morning": [
                {
                    "title": "Grounding Morning Routine",
                    "description": "Start your day with intention and presence",
                    "steps": [
                        "Before checking phone: 3 deep breaths",
                        "Write 3 things you're grateful for",
                        "Set 1 gentle intention for the day",
                        "Hydrate and gentle stretching",
                        "Brief meditation or grounding exercise"
                    ],
                    "why_helpful": "Creates emotional stability before daily stress",
                    "target_pattern": "morning anxiety and overwhelm"
                }
            ],
            "evening": [
                {
                    "title": "Wind-Down Evening Routine",
                    "description": "Transition peacefully into rest",
                    "steps": [
                        "Screen-free 1 hour before bed",
                        "Write down tomorrow's top 3 priorities (clear mental space)",
                        "Brief reflection: What went well today?",
                        "Progressive muscle relaxation",
                        "Reading (non-stimulating content)"
                    ],
                    "why_helpful": "Reduces rumination and improves sleep quality",
                    "target_pattern": "insomnia and nighttime anxiety"
                }
            ],
            "stress": [
                {
                    "title": "Emergency De-stress Protocol",
                    "description": "Use when overwhelm hits",
                    "steps": [
                        "STOP: Pause what you're doing",
                        "5-4-3-2-1 grounding (engage senses)",
                        "Box breathing: 4-4-4-4",
                        "Name the emotion without judgment",
                        "One small action you CAN control right now"
                    ],
                    "why_helpful": "Interrupts panic escalation and restores presence",
                    "target_pattern": "acute stress and panic"
                }
            ],
            "low_mood": [
                {
                    "title": "Depression-Gentle Activity Schedule",
                    "description": "Small actions when everything feels heavy",
                    "steps": [
                        "One micro-task: brush teeth or drink water",
                        "5 minutes outside (sunlight + nature)",
                        "Move body gently (walk, stretch)",
                        "Connect: text one person",
                        "Accomplish ONE tiny thing (make bed, wash face)"
                    ],
                    "why_helpful": "Breaks inertia without overwhelming expectations",
                    "target_pattern": "low motivation and anhedonia"
                }
            ]
        }

    def _load_grounding_techniques(self) -> List[Dict]:
        return [
            {
                "name": "5-4-3-2-1 Grounding",
                "description": "Sensory grounding to interrupt anxiety and dissociation",
                "steps": [
                    "Name 5 things you can see",
                    "Name 4 things you can touch",
                    "Name 3 things you can hear",
                    "Name 2 things you can smell",
                    "Name 1 thing you can taste"
                ],
                "when_to_use": "Panic, anxiety, dissociation, intrusive thoughts"
            },
            {
                "name": "Box Breathing",
                "description": "Regulated breathing to calm nervous system",
                "steps": [
                    "Breathe in for 4 counts",
                    "Hold for 4 counts",
                    "Breathe out for 4 counts",
                    "Hold empty for 4 counts",
                    "Repeat 4-5 cycles"
                ],
                "when_to_use": "Anxiety, panic, overwhelm, anger"
            },
            {
                "name": "Cold Water Reset",
                "description": "Physical shock to interrupt emotional escalation",
                "steps": [
                    "Splash cold water on face",
                    "Hold ice cubes in hands",
                    "Take a cold shower",
                    "Focus on the physical sensation"
                ],
                "when_to_use": "Emotional overwhelm, dissociation, intense urges"
            },
            {
                "name": "Cognitive Defusion",
                "description": "Create distance from thoughts",
                "steps": [
                    "Notice the thought without judgment",
                    "Say: 'I'm having the thought that...'",
                    "Imagine the thought on a leaf floating down a stream",
                    "Let it pass without engaging"
                ],
                "when_to_use": "Rumination, intrusive thoughts, catastrophizing"
            },
            {
                "name": "Body Scan",
                "description": "Progressive relaxation and awareness",
                "steps": [
                    "Lie down or sit comfortably",
                    "Starting at toes, notice sensations",
                    "Progressively move up body",
                    "Breathe into areas of tension",
                    "Release on exhale"
                ],
                "when_to_use": "Tension, dissociation, sleep issues"
            },
            {
                "name": "Break the Loop",
                "description": "Interrupt rumination cycles",
                "steps": [
                    "Notice you're in a thought loop",
                    "Physically move: stand, walk, stretch",
                    "Change environment if possible",
                    "Engage in a different activity",
                    "Schedule 'worry time' for later if needed"
                ],
                "when_to_use": "Rumination, obsessive thinking, worry loops"
            }
        ]

    def get_book_recommendations(self, patterns: List[str]) -> List[Recommendation]:
        recommendations = []

        pattern_to_category = {
            "anxiety": "anxiety",
            "depression": "depression",
            "ocd": "ocd",
            "trauma": "trauma",
            "ptsd": "trauma",
            "personality": "personality"
        }

        for pattern in patterns:
            pattern_lower = pattern.lower()
            for key, category in pattern_to_category.items():
                if key in pattern_lower:
                    books = self.book_database.get(category, [])
                    for book in books[:2]:  # Top 2 per category
                        recommendations.append(Recommendation(
                            recommendation_type="book",
                            title=f"{book['title']} by {book['author']}",
                            description=f"Reading tone: {book['tone']}",
                            why_helpful=book['why_helpful'],
                            target_pattern=book['target_pattern']
                        ))

        # Add general books if specific ones not found
        if len(recommendations) < 2:
            general_books = self.book_database.get("general", [])
            for book in general_books[:2]:
                recommendations.append(Recommendation(
                    recommendation_type="book",
                    title=f"{book['title']} by {book['author']}",
                    description=f"Reading tone: {book['tone']}",
                    why_helpful=book['why_helpful'],
                    target_pattern=book['target_pattern']
                ))

        return recommendations[:4]

    def get_routine_recommendations(self, patterns: List[str], risk_level: str) -> List[Recommendation]:
        recommendations = []

        if risk_level in ["elevated", "moderate"] or any("anxiety" in p.lower() for p in patterns):
            routine = self.routine_database["stress"][0]
            recommendations.append(Recommendation(
                recommendation_type="routine",
                title=routine["title"],
                description=routine["description"],
                why_helpful=routine["why_helpful"],
                target_pattern=routine["target_pattern"]
            ))

        if any("depression" in p.lower() for p in patterns):
            routine = self.routine_database["low_mood"][0]
            recommendations.append(Recommendation(
                recommendation_type="routine",
                title=routine["title"],
                description=routine["description"],
                why_helpful=routine["why_helpful"],
                target_pattern=routine["target_pattern"]
            ))

        # Add morning routine as default
        morning_routine = self.routine_database["morning"][0]
        recommendations.append(Recommendation(
            recommendation_type="routine",
            title=morning_routine["title"],
            description=morning_routine["description"],
            why_helpful=morning_routine["why_helpful"],
            target_pattern=morning_routine["target_pattern"]
        ))

        return recommendations[:3]

    def get_grounding_techniques(self, risk_level: str, patterns: List[str]) -> List[GroundingTechnique]:
        techniques = []

        # Always include 5-4-3-2-1
        technique_data = self.grounding_techniques[0]
        techniques.append(GroundingTechnique(
            technique_name=technique_data["name"],
            description=technique_data["description"],
            steps=technique_data["steps"],
            when_to_use=technique_data["when_to_use"]
        ))

        # Add box breathing if anxiety present
        if any("anxiety" in p.lower() for p in patterns) or risk_level in ["elevated", "moderate"]:
            technique_data = self.grounding_techniques[1]
            techniques.append(GroundingTechnique(
                technique_name=technique_data["name"],
                description=technique_data["description"],
                steps=technique_data["steps"],
                when_to_use=technique_data["when_to_use"]
            ))

        # Add break the loop for rumination
        if any("rumination" in p.lower() or "ocd" in p.lower() for p in patterns):
            technique_data = self.grounding_techniques[5]
            techniques.append(GroundingTechnique(
                technique_name=technique_data["name"],
                description=technique_data["description"],
                steps=technique_data["steps"],
                when_to_use=technique_data["when_to_use"]
            ))

        # Add cold water for high risk
        if risk_level == "elevated":
            technique_data = self.grounding_techniques[2]
            techniques.append(GroundingTechnique(
                technique_name=technique_data["name"],
                description=technique_data["description"],
                steps=technique_data["steps"],
                when_to_use=technique_data["when_to_use"]
            ))

        return techniques[:3]
