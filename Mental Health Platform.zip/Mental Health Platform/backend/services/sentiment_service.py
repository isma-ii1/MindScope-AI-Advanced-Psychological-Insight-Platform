from transformers import pipeline
import torch
from typing import Dict
import logging

from backend.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SentimentAnalysisService:
    def __init__(self):
        self.model_name = settings.HF_MODEL_SENTIMENT
        self.device = 0 if torch.cuda.is_available() else -1
        self.classifier = None
        self._load_model()

    def _load_model(self):
        try:
            self.classifier = pipeline(
                "text-classification",
                model=self.model_name,
                top_k=None,
                device=self.device
            )
            logger.info(f"Sentiment model loaded: {self.model_name}")
        except Exception as e:
            logger.error(f"Failed to load sentiment model: {e}")
            raise

    def analyze(self, text: str) -> Dict:
        if not self.classifier:
            raise RuntimeError("Sentiment classifier not initialized")

        try:
            results = self.classifier(text[:512])

            sentiment_scores = {}
            for result in results[0]:
                label = result['label'].lower()
                score = result['score']
                sentiment_scores[label] = score

            # Calculate intensity (0-100 scale)
            positive = sentiment_scores.get('positive', 0)
            negative = sentiment_scores.get('negative', 0)
            neutral = sentiment_scores.get('neutral', 0)

            # Weighted intensity calculation
            intensity = (positive * 100) - (negative * 100)
            normalized_intensity = (intensity + 100) / 2  # Scale to 0-100

            polarity = "positive" if intensity > 10 else "negative" if intensity < -10 else "neutral"

            stress_level = self._calculate_stress(negative, neutral)

            return {
                "sentiment_intensity": round(normalized_intensity, 2),
                "polarity": polarity,
                "positive_score": round(positive, 3),
                "negative_score": round(negative, 3),
                "neutral_score": round(neutral, 3),
                "stress_level": stress_level,
                "explanation": self._generate_explanation(polarity, normalized_intensity, stress_level)
            }

        except Exception as e:
            logger.error(f"Sentiment analysis failed: {e}")
            return {
                "sentiment_intensity": 50.0,
                "polarity": "neutral",
                "stress_level": "unknown",
                "explanation": "Unable to analyze sentiment"
            }

    def _calculate_stress(self, negative: float, neutral: float) -> str:
        if negative > 0.6:
            return "high"
        elif negative > 0.3:
            return "moderate"
        elif neutral > 0.6:
            return "low"
        else:
            return "minimal"

    def _generate_explanation(self, polarity: str, intensity: float, stress: str) -> str:
        polarity_text = {
            "positive": "positive and uplifting",
            "negative": "negative and difficult",
            "neutral": "balanced and neutral"
        }

        stress_text = {
            "high": "High emotional stress is present, suggesting significant distress.",
            "moderate": "Moderate stress is detected, indicating some emotional difficulty.",
            "low": "Low stress is present, suggesting relative emotional stability.",
            "minimal": "Minimal stress is detected, indicating good emotional balance."
        }

        return f"The overall tone is {polarity_text.get(polarity, 'unclear')} (intensity: {int(intensity)}/100). {stress_text.get(stress, '')}"
