import re
from typing import List, Dict
import logging

from backend.models.analysis_models import DisorderPattern

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DisorderPatternService:
    def __init__(self):
        self.pattern_indicators = self._load_pattern_indicators()

    def _load_pattern_indicators(self) -> Dict:
        return {
            "anxiety": {
                "name": "Anxiety Patterns",
                "patterns": [
                    r'\b(worry|worried|anxious|nervous|panic)\b',
                    r'\bcan\'t (relax|calm|breathe)\b',
                    r'\b(racing|intrusive) thoughts\b',
                    r'\b(fear|afraid|scared)\b.*\b(all the time|constantly)\b',
                    r'\b(what if|worst case)\b'
                ],
                "weight": 0.15
            },
            "depression": {
                "name": "Depressive Patterns",
                "patterns": [
                    r'\b(depressed|sad|empty|numb)\b',
                    r'\b(no|lost) (energy|motivation|interest)\b',
                    r'\b(tired|exhausted) all the time\b',
                    r'\bcan\'t (feel|enjoy)\b',
                    r'\b(sleep|sleeping) (too much|all day|problems)\b',
                    r'\b(hopeless|helpless)\b'
                ],
                "weight": 0.15
            },
            "ocd": {
                "name": "OCD-Type Patterns",
                "patterns": [
                    r'\b(intrusive|unwanted) thoughts\b',
                    r'\b(compulsion|compulsive|ritual)\b',
                    r'\b(checking|washing|counting)\b.*\b(over and over|repeatedly)\b',
                    r'\bcan\'t stop\b.*\b(thinking|doing)\b',
                    r'\bmust (do|check|clean)\b'
                ],
                "weight": 0.2
            },
            "bipolar": {
                "name": "Mood Cycling Patterns",
                "patterns": [
                    r'\b(mood|energy) (swings|shifts)\b',
                    r'\b(manic|hypomanic|euphoric)\b',
                    r'\b(up and down|high and low)\b',
                    r'\b(racing thoughts|can\'t sleep).*\b(energy|productive)\b',
                    r'\bextreme (highs|lows)\b'
                ],
                "weight": 0.2
            },
            "ptsd": {
                "name": "Trauma Response Patterns",
                "patterns": [
                    r'\b(flashback|reliving|triggered)\b',
                    r'\b(nightmare|night terrors)\b',
                    r'\b(avoid|avoiding).*\b(remind|memory)\b',
                    r'\b(hypervigilant|on edge|startled)\b',
                    r'\b(trauma|traumatic|abuse)\b'
                ],
                "weight": 0.2
            },
            "dissociation": {
                "name": "Dissociative Patterns",
                "patterns": [
                    r'\b(dissociate|dissociating|derealization|depersonalization)\b',
                    r'\b(disconnected|detached|unreal)\b',
                    r'\b(watching myself|outside my body)\b',
                    r'\b(fog|haze|dream)\b.*\b(state|feeling)\b',
                    r'\bdon\'t feel (real|present)\b'
                ],
                "weight": 0.2
            },
            "adhd": {
                "name": "Attention Pattern",
                "patterns": [
                    r'\bcan\'t (focus|concentrate|pay attention)\b',
                    r'\b(distracted|scattered)\b',
                    r'\b(forget|forgetting).*\b(constantly|always)\b',
                    r'\b(impulsive|restless)\b',
                    r'\b(hyperfocus|fixate)\b'
                ],
                "weight": 0.15
            },
            "eating_disorder": {
                "name": "Eating/Body Image Patterns",
                "patterns": [
                    r'\b(restrict|restricting|binge|purge)\b',
                    r'\b(body|weight|fat).*\b(hate|disgusting|control)\b',
                    r'\b(food|eating).*\b(control|guilt|shame)\b',
                    r'\b(calories|scale|mirror)\b.*\b(obsess|constantly)\b'
                ],
                "weight": 0.2
            },
            "social_anxiety": {
                "name": "Social Anxiety Patterns",
                "patterns": [
                    r'\b(social|people|public).*\b(anxiety|fear|panic|avoid)\b',
                    r'\b(judged|judging|watching)\b',
                    r'\bafraid.*\b(talk|speak|interact)\b',
                    r'\b(embarrass|humiliate)\b',
                    r'\bcan\'t.*\b(social|people|groups)\b'
                ],
                "weight": 0.15
            }
        }

    def analyze(self, text: str, emotion_data: Dict) -> List[DisorderPattern]:
        text_lower = text.lower()
        detected_patterns = []

        for pattern_key, pattern_data in self.pattern_indicators.items():
            score = 0.0
            matched_indicators = []

            for pattern in pattern_data["patterns"]:
                if re.search(pattern, text_lower):
                    score += pattern_data["weight"]
                    matched_indicators.append(pattern.replace(r'\b', '').replace('.*', ' '))

            # Boost score based on emotion alignment
            score = self._adjust_for_emotions(score, pattern_key, emotion_data)

            # Cap at 1.0
            score = min(score, 1.0)

            if score >= 0.25:
                explanation = self._generate_explanation(pattern_key, score, matched_indicators[:3])

                detected_patterns.append(DisorderPattern(
                    pattern_name=pattern_data["name"],
                    confidence=round(score, 3),
                    indicators=matched_indicators[:4],
                    explanation=explanation
                ))

        # Sort by confidence
        detected_patterns.sort(key=lambda x: x.confidence, reverse=True)

        return detected_patterns[:5]

    def _adjust_for_emotions(self, base_score: float, pattern_key: str, emotion_data: Dict) -> float:
        emotion_alignments = {
            "anxiety": ["fear", "nervousness"],
            "depression": ["sadness", "neutral"],
            "ocd": ["fear", "anxiety"],
            "bipolar": ["joy", "anger", "sadness"],
            "ptsd": ["fear", "anger"],
            "dissociation": ["neutral", "confusion"],
            "adhd": ["frustration"],
            "eating_disorder": ["disgust", "sadness"],
            "social_anxiety": ["fear", "nervousness"]
        }

        aligned_emotions = emotion_alignments.get(pattern_key, [])

        for emotion in emotion_data:
            if emotion.get("emotion", "").lower() in aligned_emotions:
                if emotion.get("score", 0) > 0.5:
                    base_score += 0.1

        return base_score

    def _generate_explanation(self, pattern_key: str, score: float, indicators: List[str]) -> str:
        pattern_descriptions = {
            "anxiety": "Language suggests persistent worry and fear-based thinking patterns.",
            "depression": "Expressions indicate low mood, loss of interest, and possible depressive symptoms.",
            "ocd": "Repetitive thought patterns and compulsive behaviors may be present.",
            "bipolar": "Mood fluctuation indicators suggest possible mood cycling patterns.",
            "ptsd": "Trauma-related language and avoidance behaviors are evident.",
            "dissociation": "Disconnection from reality or self is expressed.",
            "adhd": "Attention and focus difficulties are described.",
            "eating_disorder": "Body image concerns and eating-related distress are present.",
            "social_anxiety": "Fear of social situations and judgment is evident."
        }

        base_explanation = pattern_descriptions.get(pattern_key, "Pattern detected in language.")
        confidence_text = f" Confidence: {int(score*100)}%."

        note = " Note: This is linguistic pattern recognition, not a clinical diagnosis."

        return base_explanation + confidence_text + note
