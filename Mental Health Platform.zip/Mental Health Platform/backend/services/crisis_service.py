from typing import Dict, List
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CrisisResourceService:
    def __init__(self):
        self.hotlines = self._load_hotlines()

    def _load_hotlines(self) -> Dict:
        return {
            "international": {
                "name": "International Association for Suicide Prevention",
                "url": "https://www.iasp.info/resources/Crisis_Centres/",
                "description": "Directory of crisis centers worldwide"
            },
            "us": [
                {
                    "name": "988 Suicide & Crisis Lifeline",
                    "number": "988",
                    "description": "24/7 free and confidential support",
                    "method": "Call or text 988"
                },
                {
                    "name": "Crisis Text Line",
                    "number": "Text HOME to 741741",
                    "description": "24/7 text-based crisis support",
                    "method": "Text-based"
                }
            ],
            "uk": [
                {
                    "name": "Samaritans",
                    "number": "116 123",
                    "description": "24/7 confidential emotional support",
                    "method": "Call or email jo@samaritans.org"
                },
                {
                    "name": "Crisis Text Line UK",
                    "number": "Text SHOUT to 85258",
                    "description": "24/7 text-based support",
                    "method": "Text-based"
                }
            ],
            "canada": [
                {
                    "name": "Talk Suicide Canada",
                    "number": "1-833-456-4566",
                    "description": "24/7 bilingual support",
                    "method": "Call or text"
                },
                {
                    "name": "Kids Help Phone",
                    "number": "1-800-668-6868",
                    "description": "Support for youth (text CONNECT to 686868)",
                    "method": "Call or text"
                }
            ],
            "australia": [
                {
                    "name": "Lifeline",
                    "number": "13 11 14",
                    "description": "24/7 crisis support and suicide prevention",
                    "method": "Call or text"
                },
                {
                    "name": "Beyond Blue",
                    "number": "1300 22 4636",
                    "description": "Mental health support and information",
                    "method": "Call or chat online"
                }
            ],
            "europe": [
                {
                    "name": "Befrienders Worldwide",
                    "url": "https://www.befrienders.org/",
                    "description": "Global directory of emotional support centers"
                }
            ]
        }

    def get_resources(self, risk_level: str, region: str = None) -> Dict:
        resources = {
            "show_resources": risk_level in ["elevated", "moderate"],
            "risk_level": risk_level,
            "message": self._get_message(risk_level),
            "hotlines": []
        }

        if resources["show_resources"]:
            if region and region.lower() in self.hotlines:
                resources["hotlines"] = self.hotlines[region.lower()]
            else:
                # Provide US + International as default
                resources["hotlines"] = self.hotlines["us"]
                resources["hotlines"].append(self.hotlines["international"])

        return resources

    def _get_message(self, risk_level: str) -> str:
        messages = {
            "elevated": "You don't have to face this alone. Crisis support is available 24/7, and reaching out is a sign of strength, not weakness.",
            "moderate": "If things feel overwhelming, professional support is available. You deserve care and understanding.",
            "low": "Remember that support is always available if you need it.",
            "minimal": ""
        }
        return messages.get(risk_level, "")

    def get_all_regions(self) -> List[str]:
        return ["us", "uk", "canada", "australia", "europe", "international"]
