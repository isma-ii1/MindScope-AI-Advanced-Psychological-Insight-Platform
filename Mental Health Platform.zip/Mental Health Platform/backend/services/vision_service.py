from transformers import pipeline, ViTImageProcessor, ViTForImageClassification
from PIL import Image
import torch
from typing import Dict, List
import logging

from backend.models.analysis_models import VisionAnalysis
from backend.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VisionAnalysisService:
    def __init__(self):
        self.model_name = settings.HF_MODEL_VISION
        self.device = 0 if torch.cuda.is_available() else -1
        self.processor = None
        self.model = None
        self._model_loaded = False

    def _load_model(self):
        """Lazy load model only when needed to save memory"""
        if self._model_loaded:
            return

        try:
            logger.info(f"Loading vision model: {self.model_name}")

            # Load with low memory configuration
            self.processor = ViTImageProcessor.from_pretrained(
                self.model_name,
                cache_dir=None,  # Use default cache
                local_files_only=False
            )

            self.model = ViTForImageClassification.from_pretrained(
                self.model_name,
                cache_dir=None,
                local_files_only=False,
                low_cpu_mem_usage=True,  # Enable low memory mode
                torch_dtype=torch.float32  # Use float32 for CPU
            )

            # Only move to GPU if available, otherwise keep on CPU
            if torch.cuda.is_available():
                self.model = self.model.cuda()
            else:
                # Keep model on CPU and set to eval mode
                self.model.eval()

            self._model_loaded = True
            logger.info(f"Vision model loaded successfully: {self.model_name}")

        except Exception as e:
            logger.error(f"Failed to load vision model: {e}")
            # Don't raise - allow graceful degradation
            self._model_loaded = False
            raise

    def analyze(self, image_path: str) -> VisionAnalysis:
        try:
            # Load model if not already loaded (lazy loading)
            if not self._model_loaded:
                self._load_model()

            # Open and resize image to save memory
            image = Image.open(image_path)
            # Resize if too large (max 800x800)
            max_size = 800
            if max(image.size) > max_size:
                ratio = max_size / max(image.size)
                new_size = tuple(int(dim * ratio) for dim in image.size)
                image = image.resize(new_size, Image.Resampling.LANCZOS)

            image = image.convert('RGB')

            # Process image
            inputs = self.processor(images=image, return_tensors="pt")

            if torch.cuda.is_available():
                inputs = {k: v.cuda() for k, v in inputs.items()}

            # Get predictions
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits

            # Get top predictions
            probs = torch.nn.functional.softmax(logits, dim=-1)
            top_probs, top_indices = torch.topk(probs, k=5)

            predictions = []
            for prob, idx in zip(top_probs[0], top_indices[0]):
                label = self.model.config.id2label[idx.item()]
                predictions.append({
                    'label': label,
                    'score': prob.item()
                })

            # Psychological interpretation
            detected_emotions = self._extract_emotions(predictions)
            facial_expression = self._detect_facial_expression(predictions)
            scene_interpretation = self._interpret_scene(predictions)
            symbolic_cues = self._extract_symbolic_cues(predictions)
            distress_indicators = self._detect_distress(predictions)
            psychological_interpretation = self._generate_psychological_interpretation(
                detected_emotions, scene_interpretation, distress_indicators
            )

            return VisionAnalysis(
                detected_emotions=detected_emotions,
                facial_expression=facial_expression,
                scene_interpretation=scene_interpretation,
                symbolic_cues=symbolic_cues,
                distress_indicators=distress_indicators,
                psychological_interpretation=psychological_interpretation
            )

        except Exception as e:
            logger.error(f"Vision analysis failed: {e}")
            return VisionAnalysis(
                detected_emotions=[],
                facial_expression=None,
                scene_interpretation="Unable to analyze image",
                symbolic_cues=[],
                distress_indicators=[],
                psychological_interpretation="Image analysis unavailable"
            )

    def _extract_emotions(self, predictions: List[Dict]) -> List[str]:
        emotion_keywords = {
            'sad': 'sadness',
            'happy': 'joy',
            'angry': 'anger',
            'fear': 'fear',
            'smile': 'joy',
            'crying': 'sadness',
            'frown': 'sadness',
            'worried': 'anxiety'
        }

        emotions = []
        for pred in predictions:
            label_lower = pred['label'].lower()
            for keyword, emotion in emotion_keywords.items():
                if keyword in label_lower and pred['score'] > 0.1:
                    emotions.append(emotion)

        return list(set(emotions))[:4]

    def _detect_facial_expression(self, predictions: List[Dict]) -> str:
        face_keywords = ['face', 'person', 'portrait', 'head', 'smile', 'expression']

        for pred in predictions:
            label_lower = pred['label'].lower()
            if any(keyword in label_lower for keyword in face_keywords):
                if pred['score'] > 0.3:
                    return pred['label']

        return None

    def _interpret_scene(self, predictions: List[Dict]) -> str:
        scene_descriptors = {
            'dark': 'low-light or dark environment',
            'night': 'nighttime setting',
            'alone': 'solitary scene',
            'room': 'indoor environment',
            'bedroom': 'private personal space',
            'empty': 'sparse or empty space',
            'crowd': 'populated environment',
            'nature': 'natural outdoor setting',
            'urban': 'urban environment'
        }

        top_label = predictions[0]['label'].lower()

        for keyword, descriptor in scene_descriptors.items():
            if keyword in top_label:
                return descriptor

        return f"Scene shows: {predictions[0]['label']}"

    def _extract_symbolic_cues(self, predictions: List[Dict]) -> List[str]:
        symbolic_objects = {
            'mirror': 'self-reflection, identity concerns',
            'bed': 'rest, withdrawal, isolation',
            'phone': 'connection seeking or social media',
            'window': 'boundary between inner and outer world',
            'door': 'transition, escape, barrier',
            'book': 'seeking knowledge or escape',
            'medication': 'health management',
            'razor': 'self-harm concern',
            'rope': 'concerning object',
            'pills': 'medication or risk indicator'
        }

        cues = []
        for pred in predictions:
            label_lower = pred['label'].lower()
            for obj, meaning in symbolic_objects.items():
                if obj in label_lower and pred['score'] > 0.2:
                    cues.append(meaning)

        return cues[:4]

    def _detect_distress(self, predictions: List[Dict]) -> List[str]:
        distress_keywords = {
            'dark': 'darkness may indicate low mood',
            'alone': 'isolation patterns present',
            'crying': 'visible emotional distress',
            'sad': 'sadness expressed',
            'closed': 'withdrawal or avoidance',
            'empty': 'emptiness or void',
            'chaos': 'disorganization present',
            'mess': 'environmental neglect'
        }

        indicators = []
        for pred in predictions:
            label_lower = pred['label'].lower()
            for keyword, indicator in distress_keywords.items():
                if keyword in label_lower and pred['score'] > 0.15:
                    indicators.append(indicator)

        return indicators[:5]

    def _generate_psychological_interpretation(
        self,
        emotions: List[str],
        scene: str,
        distress: List[str]
    ) -> str:
        interpretation = "Visual analysis suggests: "

        if emotions:
            interpretation += f"Emotional tone reflects {', '.join(emotions)}. "

        interpretation += f"The environment ({scene}) "

        if distress:
            interpretation += f"shows some concerning elements: {', '.join(distress[:2])}. "
            interpretation += "These visual cues may reflect current emotional state or environment. "
        else:
            interpretation += "appears relatively neutral. "

        interpretation += "Consider how your surroundings influence your mental state."

        return interpretation
