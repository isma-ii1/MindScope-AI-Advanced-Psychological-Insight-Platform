from typing import Dict, Optional, List, Any
import logging
from datetime import datetime

from langgraph.graph import StateGraph, END
from typing_extensions import TypedDict

from backend.config.database import DatabaseManager
from backend.models.analysis_models import AnalysisResult
from backend.services.emotion_service import EmotionAnalysisService
from backend.services.sentiment_service import SentimentAnalysisService
from backend.services.cognitive_service import CognitiveDistortionService
from backend.services.risk_service import RiskAssessmentService
from backend.services.disorder_service import DisorderPatternService
from backend.services.vision_service import VisionAnalysisService
from backend.services.audio_service import AudioService
from backend.services.recommendation_service import RecommendationService
from backend.services.summary_service import SummaryService
from backend.services.crisis_service import CrisisResourceService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# LangGraph State Definition
class AnalysisState(TypedDict):
    input_text: str
    input_image_path: Optional[str]
    input_audio_path: Optional[str]
    user_id: str
    raw_emotions: List[Dict]
    sentiment_data: Dict
    cognitive_distortions: List[Dict]
    rumination_data: Dict
    risk_assessment: Dict
    disorder_patterns: List[Dict]
    vision_analysis: Optional[Dict]
    audio_analysis: Optional[Dict]
    recommendations: List[Dict]
    grounding_techniques: List[Dict]
    psychological_summary: Dict
    crisis_resources: Dict
    analysis_result: Optional[AnalysisResult]
    timestamp: datetime

class AnalysisOrchestrator:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager

        # Initialize services
        self.emotion_service = EmotionAnalysisService()
        self.sentiment_service = SentimentAnalysisService()
        self.cognitive_service = CognitiveDistortionService()
        self.risk_service = RiskAssessmentService()
        self.audio_service = AudioService()
        self.disorder_service = DisorderPatternService()
        self.vision_service = VisionAnalysisService()
        self.recommendation_service = RecommendationService()
        self.summary_service = SummaryService()
        self.crisis_service = CrisisResourceService()

        # Build LangGraph workflow
        self.workflow = self._build_workflow()

    def _build_workflow(self):
        workflow = StateGraph(AnalysisState)

        # Define nodes
        workflow.add_node("preprocess", self.preprocess_node)
        workflow.add_node("analyze_emotion", self.emotion_node)
        workflow.add_node("analyze_sentiment", self.sentiment_node)
        workflow.add_node("analyze_cognitive", self.cognitive_node)
        workflow.add_node("assess_risk", self.risk_node)
        workflow.add_node("detect_patterns", self.pattern_node)
        workflow.add_node("analyze_vision", self.vision_node)
        workflow.add_node("analyze_audio", self.audio_node)
        workflow.add_node("generate_recommendations", self.recommendation_node)
        workflow.add_node("generate_summary", self.summary_node)
        workflow.add_node("get_crisis_resources", self.crisis_node)
        workflow.add_node("persist_results", self.persistence_node)

        # Define edges (workflow sequence)
        workflow.add_edge("preprocess", "analyze_emotion")
        workflow.add_edge("analyze_emotion", "analyze_sentiment")
        workflow.add_edge("analyze_sentiment", "analyze_cognitive")
        workflow.add_edge("analyze_cognitive", "assess_risk")
        workflow.add_edge("assess_risk", "detect_patterns")
        workflow.add_edge("detect_patterns", "analyze_vision")
        workflow.add_edge("analyze_vision", "analyze_audio")
        workflow.add_edge("analyze_audio", "generate_recommendations")
        workflow.add_edge("generate_recommendations", "generate_summary")
        workflow.add_edge("generate_summary", "get_crisis_resources")
        workflow.add_edge("get_crisis_resources", "persist_results")

        # End after persistence
        workflow.add_edge("persist_results", END)

        # Set entry point
        workflow.set_entry_point("preprocess")

        return workflow.compile()

    # Node implementations
    def preprocess_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Preprocessing input")
        state["timestamp"] = datetime.utcnow()
        return state

    def emotion_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Analyzing emotions")
        text = state.get("input_text", "")
        if text:
            emotions = self.emotion_service.analyze(text)
            state["raw_emotions"] = [
                {
                    "emotion": e.emotion,
                    "score": e.score,
                    "intensity": e.intensity,
                    "explanation": e.explanation
                }
                for e in emotions
            ]
        else:
            state["raw_emotions"] = []
        return state

    def sentiment_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Analyzing sentiment")
        text = state.get("input_text", "")
        if text:
            sentiment = self.sentiment_service.analyze(text)
            state["sentiment_data"] = sentiment
        else:
            state["sentiment_data"] = {}
        return state

    def cognitive_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Analyzing cognitive distortions")
        text = state.get("input_text", "")
        if text:
            distortions = self.cognitive_service.analyze(text)
            rumination = self.cognitive_service.detect_rumination(text)

            state["cognitive_distortions"] = [
                {
                    "distortion_type": d.distortion_type,
                    "confidence": d.confidence,
                    "evidence": d.evidence,
                    "reframe_suggestion": d.reframe_suggestion
                }
                for d in distortions
            ]
            state["rumination_data"] = rumination
        else:
            state["cognitive_distortions"] = []
            state["rumination_data"] = {}
        return state

    def risk_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Assessing risk")
        text = state.get("input_text", "")
        emotions = state.get("raw_emotions", [])

        if text:
            risk = self.risk_service.analyze(text, emotions)
            state["risk_assessment"] = {
                "overall_risk_level": risk.overall_risk_level,
                "risk_score": risk.risk_score,
                "self_harm_indicators": risk.self_harm_indicators,
                "protective_factors": risk.protective_factors,
                "explanation": risk.explanation,
                "recommended_action": risk.recommended_action
            }
        else:
            state["risk_assessment"] = {}
        return state

    def pattern_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Detecting disorder patterns")
        text = state.get("input_text", "")
        emotions = state.get("raw_emotions", [])

        if text:
            patterns = self.disorder_service.analyze(text, emotions)
            state["disorder_patterns"] = [
                {
                    "pattern_name": p.pattern_name,
                    "confidence": p.confidence,
                    "indicators": p.indicators,
                    "explanation": p.explanation
                }
                for p in patterns
            ]
        else:
            state["disorder_patterns"] = []
        return state

    def vision_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Analyzing vision (if image provided)")
        image_path = state.get("input_image_path")

        if image_path:
            try:
                vision = self.vision_service.analyze(image_path)
                state["vision_analysis"] = {
                    "detected_emotions": vision.detected_emotions,
                    "facial_expression": vision.facial_expression,
                    "scene_interpretation": vision.scene_interpretation,
                    "symbolic_cues": vision.symbolic_cues,
                    "distress_indicators": vision.distress_indicators,
                    "psychological_interpretation": vision.psychological_interpretation
                }
                logger.info("Vision analysis completed successfully")
            except Exception as e:
                logger.error(f"Vision analysis failed: {e}")
                # Graceful degradation - continue without vision analysis
                state["vision_analysis"] = {
                    "detected_emotions": [],
                    "facial_expression": "Unable to analyze (insufficient memory)",
                    "scene_interpretation": "Vision analysis unavailable due to system resource constraints",
                    "symbolic_cues": [],
                    "distress_indicators": [],
                    "psychological_interpretation": "Image analysis could not be completed. Text-based emotional analysis is available."
                }
        else:
            state["vision_analysis"] = None
        return state

    def audio_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Analyzing audio (if audio provided)")
        audio_path = state.get("input_audio_path")

        if audio_path:
            audio_result = self.audio_service.analyze_audio(audio_path)
            state["audio_analysis"] = {
                "emotions": audio_result.get("emotions", []),
                "voice_features": audio_result.get("voice_features", {}),
                "confidence": audio_result.get("confidence", 0.5),
                "note": audio_result.get("note", "")
            }
        else:
            state["audio_analysis"] = None
        return state

    def recommendation_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Generating recommendations")

        patterns = state.get("disorder_patterns", [])
        risk = state.get("risk_assessment", {})

        pattern_names = [p["pattern_name"] for p in patterns]
        risk_level = risk.get("overall_risk_level", "minimal")

        # Get book recommendations
        books = self.recommendation_service.get_book_recommendations(pattern_names)

        # Get routine recommendations
        routines = self.recommendation_service.get_routine_recommendations(pattern_names, risk_level)

        # Get grounding techniques
        grounding = self.recommendation_service.get_grounding_techniques(risk_level, pattern_names)

        state["recommendations"] = [
            {
                "recommendation_type": r.recommendation_type,
                "title": r.title,
                "description": r.description,
                "why_helpful": r.why_helpful,
                "target_pattern": r.target_pattern
            }
            for r in (books + routines)
        ]

        state["grounding_techniques"] = [
            {
                "technique_name": g.technique_name,
                "description": g.description,
                "steps": g.steps,
                "when_to_use": g.when_to_use
            }
            for g in grounding
        ]

        return state

    def summary_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Generating psychological summary")

        from backend.models.analysis_models import EmotionScore, CognitiveDistortion, DisorderPattern

        # Reconstruct objects for summary service
        emotions = [
            EmotionScore(
                emotion=e["emotion"],
                score=e["score"],
                intensity=e["intensity"],
                explanation=e["explanation"]
            )
            for e in state.get("raw_emotions", [])
        ]

        distortions = [
            CognitiveDistortion(
                distortion_type=d["distortion_type"],
                confidence=d["confidence"],
                evidence=d["evidence"],
                reframe_suggestion=d["reframe_suggestion"]
            )
            for d in state.get("cognitive_distortions", [])
        ]

        patterns = [
            DisorderPattern(
                pattern_name=p["pattern_name"],
                confidence=p["confidence"],
                indicators=p["indicators"],
                explanation=p["explanation"]
            )
            for p in state.get("disorder_patterns", [])
        ]

        summary = self.summary_service.generate_summary(
            emotions=emotions,
            sentiment_data=state.get("sentiment_data", {}),
            cognitive_distortions=distortions,
            disorder_patterns=patterns,
            risk_assessment=state.get("risk_assessment", {})
        )

        state["psychological_summary"] = {
            "primary_emotions": summary.primary_emotions,
            "emotional_state": summary.emotional_state,
            "cognitive_patterns": summary.cognitive_patterns,
            "stress_level": summary.stress_level,
            "mental_state_description": summary.mental_state_description,
            "key_insights": summary.key_insights
        }

        return state

    def crisis_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Fetching crisis resources")

        risk = state.get("risk_assessment", {})
        risk_level = risk.get("overall_risk_level", "minimal")

        crisis_resources = self.crisis_service.get_resources(risk_level)
        state["crisis_resources"] = crisis_resources

        return state

    def persistence_node(self, state: AnalysisState) -> AnalysisState:
        logger.info("Persisting to MongoDB")

        from backend.models.analysis_models import (
            AnalysisResult, EmotionScore, CognitiveDistortion,
            RiskAssessment, DisorderPattern, Recommendation,
            GroundingTechnique, VisionAnalysis, PsychologicalSummary
        )

        # Reconstruct analysis result
        result = AnalysisResult(
            user_id=state["user_id"],
            input_text=state.get("input_text"),
            input_image_metadata={"path": state.get("input_image_path")} if state.get("input_image_path") else None,
            created_at=state["timestamp"]
        )

        # Emotions
        result.emotions = [
            EmotionScore(**e) for e in state.get("raw_emotions", [])
        ]

        # Sentiment
        result.sentiment_intensity = state.get("sentiment_data", {}).get("sentiment_intensity", 0.0)

        # Cognitive distortions
        result.cognitive_distortions = [
            CognitiveDistortion(**d) for d in state.get("cognitive_distortions", [])
        ]

        # Risk
        risk_data = state.get("risk_assessment", {})
        if risk_data:
            result.risk_assessment = RiskAssessment(**risk_data)

        # Disorder patterns
        result.disorder_patterns = [
            DisorderPattern(**p) for p in state.get("disorder_patterns", [])
        ]

        # Vision
        vision_data = state.get("vision_analysis")
        if vision_data:
            result.vision_analysis = VisionAnalysis(**vision_data)

        # Recommendations
        result.recommendations = [
            Recommendation(**r) for r in state.get("recommendations", [])
        ]

        # Grounding
        result.grounding_techniques = [
            GroundingTechnique(**g) for g in state.get("grounding_techniques", [])
        ]

        # Summary
        summary_data = state.get("psychological_summary", {})
        if summary_data:
            result.psychological_summary = PsychologicalSummary(**summary_data)

        # Persist to MongoDB
        analysis_id = self.db_manager.insert_analysis(result.to_dict())
        result.analysis_id = analysis_id

        state["analysis_result"] = result

        return state

    # Public methods
    def analyze_text(self, text: str, user_id: str = "anonymous") -> Dict:
        initial_state = AnalysisState(
            input_text=text,
            input_image_path=None,
            user_id=user_id,
            raw_emotions=[],
            sentiment_data={},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={},
            disorder_patterns=[],
            vision_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={},
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        final_state = self.workflow.invoke(initial_state)
        result = final_state["analysis_result"]

        return result.to_dict()

    def analyze_image(self, image_path: str, user_id: str = "anonymous", text_context: str = "") -> Dict:
        initial_state = AnalysisState(
            input_text=text_context,
            input_image_path=image_path,
            user_id=user_id,
            raw_emotions=[],
            sentiment_data={},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={},
            disorder_patterns=[],
            vision_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={},
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        final_state = self.workflow.invoke(initial_state)
        result = final_state["analysis_result"]

        return result.to_dict()

    def analyze_multimodal(self, text: str, image_path: Optional[str], audio_path: Optional[str] = None, user_id: str = "anonymous") -> Dict:
        initial_state = AnalysisState(
            input_text=text,
            input_image_path=image_path,
            input_audio_path=audio_path,
            user_id=user_id,
            raw_emotions=[],
            sentiment_data={},
            cognitive_distortions=[],
            rumination_data={},
            risk_assessment={},
            disorder_patterns=[],
            vision_analysis=None,
            audio_analysis=None,
            recommendations=[],
            grounding_techniques=[],
            psychological_summary={},
            crisis_resources={},
            analysis_result=None,
            timestamp=datetime.utcnow()
        )

        final_state = self.workflow.invoke(initial_state)
        result = final_state["analysis_result"]

        return result.to_dict()
