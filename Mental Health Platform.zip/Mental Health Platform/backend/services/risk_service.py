import re
from typing import List, Dict
import logging

from backend.models.analysis_models import RiskAssessment
from backend.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RiskAssessmentService:
    def __init__(self):
        self.crisis_keywords = settings.CRISIS_KEYWORDS
        self.risk_patterns = self._load_risk_patterns()
        self.protective_patterns = self._load_protective_patterns()

    def _load_risk_patterns(self) -> Dict:
        return {
            "explicit_harm": {
                "weight": 1.0,
                "patterns": [
                    r'\b(kill|end|take) (my|own) life\b',
                    r'\bsuicid(e|al|ality)\b',
                    r'\bwant to die\b',
                    r'\bbetter off dead\b',
                    r'\bcan\'t (go on|continue|live)\b',
                    r'\bi am suicidal\b',
                    r'\bthink.*suicid',
                    r'\bfeeling suicidal\b'
                ]
            },
            "self_harm": {
                "weight": 0.9,
                "patterns": [
                    r'\b(cut|cutting|harm|hurt) (myself|me)\b',
                    r'\bself[- ]harm\b',
                    r'\b(burn|burning) myself\b',
                    r'\boverdose\b'
                ]
            },
            "hopelessness": {
                "weight": 0.7,
                "patterns": [
                    r'\bno (hope|point|reason)\b',
                    r'\bhopeless\b',
                    r'\bnothing (matters|helps|works)\b',
                    r'\bgive up\b',
                    r'\bno way out\b'
                ]
            },
            "worthlessness": {
                "weight": 0.6,
                "patterns": [
                    r'\b(worthless|useless|burden)\b',
                    r'\beveryone.*better.*without me\b',
                    r'\bno value\b',
                    r'\bwaste of space\b'
                ]
            },
            "isolation": {
                "weight": 0.5,
                "patterns": [
                    r'\b(alone|lonely|isolated)\b',
                    r'\bno one (cares|understands)\b',
                    r'\bno (friends|support)\b',
                    r'\bcompletely alone\b'
                ]
            },
            "plan_indicators": {
                "weight": 1.0,
                "patterns": [
                    r'\b(plan|planning|method|how to)\b.*\b(end|kill|die)\b',
                    r'\b(pills|rope|bridge|gun)\b',
                    r'\bwhen I (do it|end it)\b'
                ]
            }
        }

    def _load_protective_patterns(self) -> List[str]:
        return [
            r'\b(hope|hopeful|better|improve)\b',
            r'\b(family|friends|people|loved ones)\b.*\b(care|support|help)\b',
            r'\b(want|trying|working) (to|on)\b.*\b(get better|improve|help)\b',
            r'\b(therapy|counseling|treatment|medication)\b',
            r'\b(reasons|things|people).*\b(live|stay|continue)\b',
            r'\b(grateful|thankful|appreciate)\b'
        ]

    def analyze(self, text: str, emotion_data: Dict) -> RiskAssessment:
        text_lower = text.lower()

        risk_score = 0.0
        indicators = []

        # CRITICAL: Check for explicit suicidal ideation first
        explicit_harm_patterns = self.risk_patterns.get("explicit_harm", {}).get("patterns", [])
        for pattern in explicit_harm_patterns:
            if re.search(pattern, text_lower):
                # IMMEDIATE HIGH RISK - suicidal ideation detected
                risk_score = max(risk_score, 0.85)  # Ensure at least "elevated" or "severe"
                indicators.append("Explicit Harm / Suicidal Ideation")
                break

        # Analyze risk patterns
        for category, data in self.risk_patterns.items():
            for pattern in data["patterns"]:
                if re.search(pattern, text_lower):
                    risk_score += data["weight"] * 0.25  # Increased from 0.2
                    category_name = category.replace("_", " ").title()
                    if category_name not in indicators:
                        indicators.append(category_name)
                    break  # Count each category once

        # Incorporate emotion data
        negative_emotions = ["sadness", "fear", "anger", "disgust"]
        high_negative_emotion = any(
            emotion.get("score", 0) > 0.6
            for emotion in emotion_data
            if emotion.get("emotion", "").lower() in negative_emotions
        )

        if high_negative_emotion:
            risk_score += 0.15

        # Cap at 1.0
        risk_score = min(risk_score, 1.0)

        # Identify protective factors
        protective_factors = []
        for pattern in self.protective_patterns:
            if re.search(pattern, text_lower):
                protective_factors.append("positive connections" if "family" in pattern or "friends" in pattern
                                        else "hope for future" if "hope" in pattern
                                        else "seeking help" if "therapy" in pattern
                                        else "reasons to live")
                risk_score -= 0.05  # Reduce risk slightly

        protective_factors = list(set(protective_factors))[:4]
        risk_score = max(risk_score, 0.0)  # Don't go below 0

        # Determine risk level
        if risk_score >= settings.RISK_THRESHOLD_HIGH:
            level = "elevated"
            action = "immediate_support"
        elif risk_score >= settings.RISK_THRESHOLD_MEDIUM:
            level = "moderate"
            action = "professional_guidance"
        elif risk_score >= settings.RISK_THRESHOLD_LOW:
            level = "low"
            action = "self_care"
        else:
            level = "minimal"
            action = "continue_monitoring"

        explanation = self._generate_explanation(level, indicators, protective_factors)
        recommended_action = self._get_recommended_action(action)

        return RiskAssessment(
            overall_risk_level=level,
            risk_score=round(risk_score, 3),
            self_harm_indicators=list(set(indicators))[:6],
            protective_factors=protective_factors,
            explanation=explanation,
            recommended_action=recommended_action
        )

    def _generate_explanation(self, level: str, indicators: List[str], protective: List[str]) -> str:
        level_text = {
            "elevated": "The language suggests significant distress and possible thoughts of self-harm.",
            "moderate": "Some concerning patterns are present that warrant attention and support.",
            "low": "Mild distress indicators are present, though protective factors are also noted.",
            "minimal": "The emotional state appears relatively stable with minimal immediate concerns."
        }

        base = level_text.get(level, "")

        if indicators:
            base += f" Indicators include: {', '.join(indicators[:3])}."

        if protective:
            base += f" Protective factors present: {', '.join(protective[:2])}."

        return base

    def _get_recommended_action(self, action: str) -> str:
        actions = {
            "immediate_support": "Consider reaching out to a crisis helpline or trusted person. You don't have to face this alone. Grounding techniques may help stabilize in this moment.",
            "professional_guidance": "Speaking with a mental health professional could provide valuable support and strategies. In the meantime, grounding and self-care are important.",
            "self_care": "Continue using coping strategies and self-care practices. Monitor your emotional state and reach out if things feel overwhelming.",
            "continue_monitoring": "Maintain awareness of your emotional patterns. Keep using healthy coping strategies and stay connected to support."
        }
        return actions.get(action, "Continue self-awareness and reach out if needed.")
