from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
import torch
from typing import List, Dict
import logging

from backend.models.analysis_models import EmotionScore
from backend.config.settings import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EmotionAnalysisService:
    def __init__(self):
        self.model_name = settings.HF_MODEL_EMOTION
        self.device = 0 if torch.cuda.is_available() else -1
        self.classifier = None
        self._load_model()

    def _load_model(self):
        try:
            self.classifier = pipeline(
                "text-classification",
                model=self.model_name,
                top_k=None,
                device=self.device
            )
            logger.info(f"Emotion model loaded: {self.model_name}")
        except Exception as e:
            logger.error(f"Failed to load emotion model: {e}")
            raise

    def analyze(self, text: str) -> List[EmotionScore]:
        if not self.classifier:
            raise RuntimeError("Emotion classifier not initialized")

        try:
            results = self.classifier(text[:512])  # Truncate to model max length

            emotion_scores = []
            for result in results[0]:
                emotion = result['label']
                score = result['score']

                intensity = self._get_intensity(score)
                explanation = self._generate_explanation(emotion, score)

                emotion_scores.append(EmotionScore(
                    emotion=emotion,
                    score=round(score, 3),
                    intensity=intensity,
                    explanation=explanation
                ))

            # Sort by score descending
            emotion_scores.sort(key=lambda x: x.score, reverse=True)

            return emotion_scores[:7]  # Return top 7 emotions

        except Exception as e:
            logger.error(f"Emotion analysis failed: {e}")
            return []

    def _get_intensity(self, score: float) -> str:
        if score >= 0.7:
            return "strong"
        elif score >= 0.4:
            return "moderate"
        else:
            return "mild"

    def _generate_explanation(self, emotion: str, score: float) -> str:
        intensity_map = {
            "strong": "clearly present",
            "moderate": "noticeably present",
            "mild": "subtly present"
        }

        intensity = self._get_intensity(score)
        intensity_text = intensity_map.get(intensity, "present")

        emotion_insights = {
            "anger": "indicates frustration or perceived injustice",
            "disgust": "suggests rejection or strong aversion",
            "fear": "reflects worry or anticipation of threat",
            "joy": "shows positive engagement and satisfaction",
            "neutral": "indicates calm or emotional balance",
            "sadness": "reveals feelings of loss or disappointment",
            "surprise": "suggests unexpected information or events"
        }

        insight = emotion_insights.get(emotion.lower(), "is detected in the text")

        return f"{emotion.capitalize()} is {intensity_text} ({int(score*100)}%), which {insight}."
