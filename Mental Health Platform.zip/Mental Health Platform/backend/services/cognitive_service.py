import re
from typing import List, Dict
import logging

from backend.models.analysis_models import CognitiveDistortion

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CognitiveDistortionService:
    def __init__(self):
        self.distortion_patterns = self._load_distortion_patterns()

    def _load_distortion_patterns(self) -> Dict:
        return {
            "all_or_nothing": {
                "name": "All-or-Nothing Thinking",
                "patterns": [
                    r'\b(always|never|everyone|nobody|everything|nothing)\b',
                    r'\b(complete|total|absolute|perfect|impossible)\b',
                    r'\b(all|every|any)\b.*\b(time|one|thing)\b'
                ],
                "keywords": ["always", "never", "all", "nothing", "everyone", "nobody", "every", "completely"],
                "description": "Viewing situations in absolute, black-and-white terms",
                "reframe": "Consider the gray areas and exceptions. What are the nuances in this situation?"
            },
            "catastrophizing": {
                "name": "Catastrophizing",
                "patterns": [
                    r'\b(disaster|catastrophe|terrible|horrible|awful|worst)\b',
                    r'\b(ruin|destroy|end|doomed)\b',
                    r'\bwhat if\b.*\b(bad|wrong|fail)\b'
                ],
                "keywords": ["disaster", "catastrophe", "terrible", "worst", "ruin", "doomed", "what if"],
                "description": "Expecting the worst possible outcome",
                "reframe": "What is the most realistic outcome? What evidence supports a less extreme possibility?"
            },
            "overgeneralization": {
                "name": "Overgeneralization",
                "patterns": [
                    r'\b(always happen|keeps happening|every time)\b',
                    r'\bthis (always|never)\b',
                    r'\b(typical|usual|again)\b'
                ],
                "keywords": ["always happens", "every time", "typical", "again", "pattern"],
                "description": "Drawing broad conclusions from single events",
                "reframe": "Is this truly a pattern, or an isolated event? What are the exceptions?"
            },
            "mind_reading": {
                "name": "Mind Reading",
                "patterns": [
                    r'\bthey (think|believe|feel|hate|dislike)\b',
                    r'\b(everyone|people) (think|know|judge)\b',
                    r'\bI know (what|that|they)\b'
                ],
                "keywords": ["they think", "everyone thinks", "people judge", "I know what"],
                "description": "Assuming you know what others are thinking without evidence",
                "reframe": "What actual evidence do you have? Could there be alternative explanations?"
            },
            "emotional_reasoning": {
                "name": "Emotional Reasoning",
                "patterns": [
                    r'\bI feel.*therefore\b',
                    r'\bfeel like.*must be\b',
                    r'\bfeeling.*means\b'
                ],
                "keywords": ["I feel therefore", "feeling means", "must be true"],
                "description": "Believing feelings are facts",
                "reframe": "Feelings are valid but not always factual. What objective evidence exists?"
            },
            "should_statements": {
                "name": "Should Statements",
                "patterns": [
                    r'\b(should|must|ought to|have to|need to)\b',
                    r'\b(supposed to|expected to)\b'
                ],
                "keywords": ["should", "must", "ought to", "have to", "supposed to"],
                "description": "Using rigid rules about how things 'should' be",
                "reframe": "Replace 'should' with 'could' or 'prefer'. What's actually within your control?"
            },
            "personalization": {
                "name": "Personalization",
                "patterns": [
                    r'\bmy fault\b',
                    r'\bI (caused|made|ruined)\b',
                    r'\bbecause of me\b'
                ],
                "keywords": ["my fault", "because of me", "I caused", "I ruined"],
                "description": "Taking excessive personal responsibility for external events",
                "reframe": "What factors were outside your control? Who else shares responsibility?"
            },
            "mental_filtering": {
                "name": "Mental Filtering",
                "patterns": [
                    r'\bonly.*negative\b',
                    r'\bcan\'t see.*positive\b',
                    r'\bjust.*bad\b'
                ],
                "keywords": ["only negative", "just the bad", "can't see positive"],
                "description": "Focusing exclusively on negative aspects while filtering out positive ones",
                "reframe": "What positive or neutral aspects exist? Practice balanced attention."
            },
            "fortune_telling": {
                "name": "Fortune Telling",
                "patterns": [
                    r'\bwill (never|definitely|certainly)\b',
                    r'\b(going to|gonna) (fail|be|happen)\b',
                    r'\bI know.*will\b'
                ],
                "keywords": ["will never", "going to fail", "definitely won't"],
                "description": "Predicting negative outcomes as certainties",
                "reframe": "You cannot predict the future with certainty. What else could happen?"
            },
            "labeling": {
                "name": "Labeling",
                "patterns": [
                    r'\bI am (a|an) (loser|failure|idiot|worthless)\b',
                    r'\bI\'m (stupid|useless|hopeless)\b'
                ],
                "keywords": ["I am a failure", "I'm worthless", "I'm stupid", "I'm useless"],
                "description": "Attaching negative labels to yourself or others",
                "reframe": "You are not your mistakes. Describe the behavior, not your identity."
            }
        }

    def analyze(self, text: str) -> List[CognitiveDistortion]:
        text_lower = text.lower()
        detected_distortions = []

        for distortion_key, distortion_data in self.distortion_patterns.items():
            confidence = 0.0
            evidence_phrases = []

            # Check regex patterns
            for pattern in distortion_data["patterns"]:
                matches = re.findall(pattern, text_lower, re.IGNORECASE)
                if matches:
                    confidence += 0.25
                    evidence_phrases.extend(matches[:2])  # Limit evidence

            # Check keywords
            keyword_count = sum(1 for keyword in distortion_data["keywords"] if keyword in text_lower)
            confidence += keyword_count * 0.15

            # Cap confidence at 1.0
            confidence = min(confidence, 1.0)

            # Add if confidence threshold met
            if confidence >= 0.3:
                evidence = ", ".join(set(evidence_phrases[:3])) if evidence_phrases else "linguistic patterns detected"

                detected_distortions.append(CognitiveDistortion(
                    distortion_type=distortion_data["name"],
                    confidence=round(confidence, 3),
                    evidence=f"Detected: '{evidence}'",
                    reframe_suggestion=distortion_data["reframe"]
                ))

        # Sort by confidence
        detected_distortions.sort(key=lambda x: x.confidence, reverse=True)

        return detected_distortions[:5]  # Return top 5

    def detect_rumination(self, text: str) -> Dict:
        rumination_indicators = [
            r'\bcan\'t stop (thinking|worrying)\b',
            r'\bkeep (thinking|going over)\b',
            r'\bover and over\b',
            r'\bagain and again\b',
            r'\bwon\'t (leave|go away)\b',
            r'\bstuck (on|in|with)\b',
            r'\bloop\b',
            r'\brepeat\b'
        ]

        text_lower = text.lower()
        rumination_score = 0

        for pattern in rumination_indicators:
            if re.search(pattern, text_lower):
                rumination_score += 0.2

        rumination_score = min(rumination_score, 1.0)

        level = "high" if rumination_score >= 0.6 else "moderate" if rumination_score >= 0.3 else "low"

        return {
            "rumination_detected": rumination_score >= 0.3,
            "rumination_score": round(rumination_score, 3),
            "level": level,
            "explanation": self._get_rumination_explanation(level)
        }

    def _get_rumination_explanation(self, level: str) -> str:
        explanations = {
            "high": "Strong signs of repetitive negative thinking detected. Your mind may be caught in a loop.",
            "moderate": "Some repetitive thought patterns present. You may be dwelling on specific concerns.",
            "low": "Minimal rumination detected. Thought patterns appear relatively flexible."
        }
        return explanations.get(level, "")
