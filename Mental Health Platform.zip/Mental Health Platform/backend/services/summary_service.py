from typing import List, Dict
import logging

from backend.models.analysis_models import PsychologicalSummary, EmotionScore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SummaryService:
    def __init__(self):
        pass

    def generate_summary(
        self,
        emotions: List[EmotionScore],
        sentiment_data: Dict,
        cognitive_distortions: List,
        disorder_patterns: List,
        risk_assessment: Dict
    ) -> PsychologicalSummary:

        # Extract primary emotions
        primary_emotions = [e.emotion for e in emotions[:3]] if emotions else []

        # Determine emotional state
        emotional_state = self._determine_emotional_state(emotions, sentiment_data)

        # Extract cognitive patterns
        cognitive_patterns = [d.distortion_type for d in cognitive_distortions[:3]]

        # Determine stress level
        stress_level = sentiment_data.get("stress_level", "unknown")

        # Generate description
        mental_state_description = self._generate_description(
            emotional_state, stress_level, primary_emotions, cognitive_patterns
        )

        # Generate key insights
        key_insights = self._generate_insights(
            emotions, cognitive_distortions, disorder_patterns, risk_assessment
        )

        return PsychologicalSummary(
            primary_emotions=primary_emotions,
            emotional_state=emotional_state,
            cognitive_patterns=cognitive_patterns,
            stress_level=stress_level,
            mental_state_description=mental_state_description,
            key_insights=key_insights
        )

    def _determine_emotional_state(self, emotions: List[EmotionScore], sentiment_data: Dict) -> str:
        if not emotions:
            return "neutral"

        top_emotion = emotions[0].emotion.lower()
        intensity = emotions[0].score

        polarity = sentiment_data.get("polarity", "neutral")

        if top_emotion in ["sadness", "fear"] and intensity > 0.6:
            return "distressed"
        elif top_emotion == "anger" and intensity > 0.6:
            return "agitated"
        elif top_emotion == "joy" and intensity > 0.5:
            return "positive"
        elif top_emotion == "neutral" or intensity < 0.4:
            return "neutral"
        elif polarity == "negative":
            return "troubled"
        else:
            return "mixed"

    def _generate_description(
        self,
        emotional_state: str,
        stress_level: str,
        emotions: List[str],
        patterns: List[str]
    ) -> str:

        state_descriptions = {
            "distressed": "You appear to be experiencing significant emotional distress",
            "agitated": "Your emotional state shows signs of agitation or frustration",
            "positive": "Your emotional state appears relatively positive",
            "neutral": "Your emotional state appears balanced and neutral",
            "troubled": "You seem to be going through a difficult time",
            "mixed": "Your emotions show a complex, mixed pattern"
        }

        description = state_descriptions.get(emotional_state, "Your emotional state is being analyzed")

        if emotions:
            description += f", with {', '.join(emotions[:2])} being most prominent."

        if stress_level in ["high", "moderate"]:
            description += f" Stress levels are {stress_level}."

        if patterns:
            description += f" Some cognitive patterns detected include {patterns[0].lower()}."

        return description

    def _generate_insights(
        self,
        emotions: List[EmotionScore],
        distortions: List,
        patterns: List,
        risk: Dict
    ) -> List[str]:

        insights = []

        # Emotion insight
        if emotions and emotions[0].score > 0.6:
            insights.append(
                f"{emotions[0].emotion.capitalize()} is strongly present, suggesting this emotion may be central to your current experience"
            )

        # Cognitive distortion insight
        if distortions:
            top_distortion = distortions[0]
            insights.append(
                f"{top_distortion.distortion_type} detected - consider questioning these thought patterns"
            )

        # Pattern insight
        if patterns:
            top_pattern = patterns[0]
            insights.append(
                f"Language patterns align with {top_pattern.pattern_name.lower()} - awareness is the first step"
            )

        # Risk insight (non-alarmist)
        risk_level = risk.get("overall_risk_level", "minimal")
        if risk_level in ["elevated", "moderate"]:
            insights.append(
                "Some concerning patterns are present - please consider reaching out for support"
            )

        # Protective factors
        protective = risk.get("protective_factors", [])
        if protective:
            insights.append(
                f"Protective factors identified: {protective[0]} - these are important strengths"
            )

        # General insight
        if not insights:
            insights.append("Your emotional patterns show complexity - self-awareness is valuable")

        return insights[:5]
