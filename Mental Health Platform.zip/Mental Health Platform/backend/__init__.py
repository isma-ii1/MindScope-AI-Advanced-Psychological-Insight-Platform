# Backend initialization
