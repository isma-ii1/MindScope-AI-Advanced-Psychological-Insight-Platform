import streamlit as st
import requests
from PIL import Image
import io
import plotly.graph_objects as go
from typing import Dict, List
import time

st.set_page_config(
    page_title="MindScope AI",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Professional Premium Design
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    /* ============================================
       SOPHISTICATED DARK THEME
    ============================================ */
    html, body, [class*="css"], .stApp {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif !important;
        background: linear-gradient(135deg, #0f1117 0%, #1a1d2e 50%, #1e1b3a 100%) !important;
        color: #e8eaf0 !important;
    }

    /* Refined background pattern */
    .stApp::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image:
            radial-gradient(circle at 20% 20%, rgba(79, 209, 197, 0.06) 0%, transparent 40%),
            radial-gradient(circle at 80% 80%, rgba(139, 92, 246, 0.06) 0%, transparent 40%),
            repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(79, 209, 197, 0.02) 2px, rgba(79, 209, 197, 0.02) 4px);
        pointer-events: none;
        z-index: 0;
    }

    #MainMenu, footer, header, .stDeployButton {
        visibility: hidden !important;
        display: none !important;
    }

    .main .block-container {
        padding: 1.5rem 2.5rem !important;
        max-width: 1300px !important;
    }

    /* ============================================
       ELEGANT HERO SECTION
    ============================================ */
    .hero-section {
        background: linear-gradient(135deg, rgba(79, 209, 197, 0.05) 0%, rgba(139, 92, 246, 0.05) 100%);
        border: 1px solid rgba(79, 209, 197, 0.15);
        border-radius: 20px;
        padding: 2.5rem 2.5rem;
        margin-bottom: 2rem;
        position: relative;
        backdrop-filter: blur(60px);
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5), 0 0 1px rgba(79, 209, 197, 0.3);
    }

    .hero-title {
        font-size: 4rem;
        font-weight: 800;
        margin: 0 0 0.75rem 0;
        background: linear-gradient(135deg, #4fd1c5 0%, #8b5cf6 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        letter-spacing: -0.04em;
        line-height: 1.1;
    }

    .hero-subtitle {
        color: #4fd1c5;
        font-size: 1.5rem;
        font-weight: 600;
        margin: 0 0 0.625rem 0;
        letter-spacing: -0.01em;
    }

    .hero-description {
        color: #9ca3af;
        font-size: 1.125rem;
        font-weight: 400;
        line-height: 1.6;
        margin-bottom: 1.5rem;
        max-width: 750px;
    }

    .feature-pills {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .feature-pill {
        background: rgba(79, 209, 197, 0.08);
        border: 1px solid rgba(79, 209, 197, 0.25);
        color: #81e6d9;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.9375rem;
        backdrop-filter: blur(10px);
    }

    /* ============================================
       REFINED INPUT SECTION
    ============================================ */
    .input-section {
        background: rgba(20, 23, 33, 0.7);
        border: 1px solid rgba(79, 209, 197, 0.12);
        border-radius: 20px;
        padding: 2rem;
        margin-bottom: 2rem;
        backdrop-filter: blur(60px);
        box-shadow: 0 6px 30px rgba(0, 0, 0, 0.4), 0 0 1px rgba(79, 209, 197, 0.2);
    }

    .section-title {
        color: #f3f4f6;
        font-size: 1.75rem;
        font-weight: 700;
        margin: 0 0 0.5rem 0;
        letter-spacing: -0.02em;
    }

    .section-subtitle {
        color: #9ca3af;
        font-size: 1.0625rem;
        font-weight: 400;
        line-height: 1.5;
        margin-bottom: 1.5rem;
    }

    /* ============================================
       PROFESSIONAL FORM ELEMENTS
    ============================================ */
    .stTextArea > div > div > textarea {
        font-family: 'Plus Jakarta Sans', sans-serif !important;
        font-size: 1.0625rem !important;
        line-height: 1.6 !important;
        border-radius: 14px !important;
        border: 1px solid rgba(79, 209, 197, 0.2) !important;
        padding: 1.25rem !important;
        background: rgba(15, 17, 23, 0.9) !important;
        color: #e5e7eb !important;
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3), inset 0 1px 2px rgba(0, 0, 0, 0.4) !important;
    }

    .stTextArea > div > div > textarea:focus {
        border-color: rgba(79, 209, 197, 0.5) !important;
        box-shadow: 0 0 0 3px rgba(79, 209, 197, 0.1), 0 6px 20px rgba(0, 0, 0, 0.4) !important;
        outline: none !important;
        background: rgba(15, 17, 23, 1) !important;
    }

    .stTextArea > div > div > textarea::placeholder {
        color: #6b7280 !important;
    }

    /* Elegant Button */
    .stButton > button {
        width: 100%;
        background: linear-gradient(135deg, #4fd1c5 0%, #8b5cf6 100%) !important;
        color: #0f1117 !important;
        font-family: 'Plus Jakarta Sans', sans-serif !important;
        font-weight: 700 !important;
        font-size: 1rem !important;
        padding: 1rem 2rem !important;
        border: none !important;
        border-radius: 12px !important;
        cursor: pointer !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 6px 20px rgba(79, 209, 197, 0.25), 0 0 1px rgba(79, 209, 197, 0.5) !important;
        letter-spacing: 0.05em;
        text-transform: uppercase;
    }

    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 10px 30px rgba(79, 209, 197, 0.35), 0 0 2px rgba(79, 209, 197, 0.7) !important;
        background: linear-gradient(135deg, #5fdfd3 0%, #9f7aea 100%) !important;
    }

    .stButton > button:active {
        transform: translateY(0px) !important;
    }

    /* File Uploader */
    .upload-card {
        background: rgba(20, 23, 33, 0.6);
        border: 1.5px dashed rgba(79, 209, 197, 0.25);
        border-radius: 14px;
        padding: 2rem 1.5rem;
        text-align: center;
        backdrop-filter: blur(40px);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .upload-card:hover {
        border-color: rgba(79, 209, 197, 0.5);
        background: rgba(20, 23, 33, 0.8);
        box-shadow: 0 0 20px rgba(79, 209, 197, 0.1);
    }

    .stFileUploader {
        background: transparent !important;
        border: none !important;
    }

    [data-testid="stFileUploadDropzone"] {
        background: transparent !important;
        border: none !important;
    }

    /* Camera Input */
    [data-testid="stCameraInput"] {
        border-radius: 14px;
        overflow: hidden;
    }

    [data-testid="stCameraInput"] video {
        border-radius: 14px;
        border: 1px solid rgba(79, 209, 197, 0.2);
    }

    /* Audio Input */
    [data-testid="stAudioInput"] {
        background: rgba(20, 23, 33, 0.6) !important;
        border: 1px solid rgba(79, 209, 197, 0.2) !important;
        border-radius: 14px !important;
        padding: 1rem !important;
    }

    /* Audio player */
    .stAudio {
        border-radius: 12px;
        overflow: hidden;
    }

    /* ============================================
       SOPHISTICATED RESULT CARDS
    ============================================ */
    .result-card {
        background: rgba(20, 23, 33, 0.7);
        border: 1px solid rgba(79, 209, 197, 0.12);
        border-radius: 18px;
        padding: 2rem;
        margin-bottom: 1.5rem;
        backdrop-filter: blur(60px);
        box-shadow: 0 6px 28px rgba(0, 0, 0, 0.35), 0 0 1px rgba(79, 209, 197, 0.2);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .result-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.45), 0 0 2px rgba(79, 209, 197, 0.4);
        border-color: rgba(79, 209, 197, 0.2);
    }

    .card-title {
        color: #f3f4f6;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0 0 1.25rem 0;
        letter-spacing: -0.01em;
    }

    /* ============================================
       REFINED ANIMATIONS
    ============================================ */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .main .block-container > div {
        animation: fadeInUp 0.5s ease-out;
    }

    /* Professional Scrollbar */
    ::-webkit-scrollbar {
        width: 10px;
    }

    ::-webkit-scrollbar-track {
        background: rgba(20, 23, 35, 0.5);
    }

    ::-webkit-scrollbar-thumb {
        background: linear-gradient(180deg, #4fd1c5, #8b5cf6);
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(180deg, #5fdfd3, #9f7aea);
    }

    /* Progress bar */
    .stProgress > div > div {
        background: linear-gradient(90deg, #4fd1c5, #8b5cf6) !important;
    }

    /* Success/Error */
    .stSuccess, .stError {
        background: rgba(20, 23, 33, 0.95) !important;
        backdrop-filter: blur(30px);
        border-radius: 12px !important;
        border: 1px solid rgba(79, 209, 197, 0.2) !important;
    }

    /* Image */
    .stImage {
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4), 0 0 1px rgba(79, 209, 197, 0.3);
        border: 1px solid rgba(79, 209, 197, 0.2);
    }

    /* Labels */
    label {
        color: #d1d5db !important;
        font-weight: 600 !important;
        font-size: 1rem !important;
    }

    /* Column spacing */
    [data-testid="column"] {
        padding: 0 1rem;
    }

    /* Upload icon */
    .upload-icon {
        font-size: 2.5rem;
        margin-bottom: 0.75rem;
        opacity: 0.5;
    }

    .upload-title {
        color: #4fd1c5;
        font-size: 1.125rem;
        font-weight: 700;
        margin-bottom: 0.375rem;
    }

    .upload-subtitle {
        color: #6b7280;
        font-size: 0.9375rem;
    }
</style>
""", unsafe_allow_html=True)

# Dynamically detect backend URL based on how frontend is accessed
import os

# Configuration: Set your backend address here
# Option 1: Use environment variable (recommended for deployment)
# Option 2: Auto-detect based on common patterns
# Option 3: Hardcode for specific network setup

BACKEND_HOST = os.environ.get('BACKEND_HOST', None)

if not BACKEND_HOST:
    # Try to detect from Streamlit server config
    # When running with --server.address 0.0.0.0, Streamlit binds to all interfaces
    # The user must access via their network IP (e.g., 192.168.2.134)

    # Check common environment variables
    if 'STREAMLIT_SERVER_ADDRESS' in os.environ:
        BACKEND_HOST = os.environ['STREAMLIT_SERVER_ADDRESS']
    else:
        # Default to localhost
        # For network access: set BACKEND_HOST environment variable to your local IP
        # Example: export BACKEND_HOST=192.168.2.134 (Linux/Mac)
        # Example: set BACKEND_HOST=192.168.2.134 (Windows)
        BACKEND_HOST = 'localhost'

API_BASE_URL = f"http://{BACKEND_HOST}:5000/api"

class MindScopeAI:
    def __init__(self):
        if 'analysis_result' not in st.session_state:
            st.session_state.analysis_result = None
        if 'user_id' not in st.session_state:
            st.session_state.user_id = "user"
        if 'backend_status' not in st.session_state:
            st.session_state.backend_status = None

    def check_backend_connection(self):
        """Check if backend is reachable"""
        try:
            response = requests.get(f"{API_BASE_URL}/health/ping", timeout=2)
            return response.status_code == 200
        except:
            return False

    def render_header(self):
        # Check backend connection
        backend_online = self.check_backend_connection()

        # Display connection status
        if not backend_online:
            st.error(f"""
            ⚠️ **Backend Not Connected**

            The backend server is not reachable at `{API_BASE_URL.replace('/api', '')}`.

            **If accessing from network IP (e.g., 192.168.2.134):**
            1. Start the backend on the server machine: `cd backend && python app.py`
            2. Set the BACKEND_HOST environment variable to your server's IP:
               - Windows: `set BACKEND_HOST=192.168.2.134 && streamlit run app.py`
               - Linux/Mac: `export BACKEND_HOST=192.168.2.134 && streamlit run app.py`

            **If accessing from localhost:**
            1. Make sure MongoDB is running (as Administrator): `net start MongoDB`
            2. Start the backend: `cd backend && python app.py`
            3. Start the frontend: `cd frontend && streamlit run app.py`
            """)

        st.markdown("""
        <div class="hero-section">
            <h1 class="hero-title">MindScope AI</h1>
            <p class="hero-subtitle">Advanced Psychological Intelligence Platform</p>
            <p class="hero-description">
                Harness the power of cutting-edge AI to understand your emotional landscape.
                Our platform provides real-time psychological analysis, cognitive pattern detection,
                and personalized mental wellness insights.
            </p>
            <div class="feature-pills">
                <div class="feature-pill">Multi-Modal Analysis</div>
                <div class="feature-pill">Real-Time Insights</div>
                <div class="feature-pill">Private & Secure</div>
                <div class="feature-pill">Evidence-Based</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    def render_input_section(self):
        st.markdown("""
        <div class="input-section">
            <h2 class="section-title">Begin Your Analysis</h2>
            <p class="section-subtitle">
                Share your thoughts in a safe, confidential environment. Our AI analyzes emotional patterns, cognitive processes, and provides comprehensive psychological insights.
            </p>
        </div>
        """, unsafe_allow_html=True)

        col1, col2, col3 = st.columns([2, 1, 1], gap="medium")

        with col1:
            text_input = st.text_area(
                "Your thoughts",
                placeholder="Express your thoughts, feelings, and experiences here. The more detail you provide, the more accurate and personalized your analysis will be...",
                height=300,
                label_visibility="collapsed",
                key="text_input_main"
            )

        with col2:
            st.markdown("""
            <div class="upload-card">
                <div class="upload-icon">📸</div>
                <div class="upload-title">Facial Analysis</div>
                <div class="upload-subtitle">Capture or upload</div>
            </div>
            """, unsafe_allow_html=True)

            # Camera capture
            camera_photo = st.camera_input("Take photo", label_visibility="collapsed", key="camera_input")

            # Or file upload
            if not camera_photo:
                image_file = st.file_uploader(
                    "Or upload image",
                    type=['png', 'jpg', 'jpeg'],
                    label_visibility="collapsed",
                    key="image_uploader"
                )
            else:
                image_file = camera_photo

            if image_file:
                st.image(image_file, use_container_width=True)

        with col3:
            st.markdown("""
            <div class="upload-card">
                <div class="upload-icon">🎤</div>
                <div class="upload-title">Voice Analysis</div>
                <div class="upload-subtitle">Record or upload</div>
            </div>
            """, unsafe_allow_html=True)

            # Audio recorder
            audio_recorded = st.audio_input("Record audio", label_visibility="collapsed", key="audio_recorder")

            # Or file upload
            if not audio_recorded:
                audio_file = st.file_uploader(
                    "Or upload audio",
                    type=['mp3', 'wav', 'm4a', 'ogg'],
                    label_visibility="collapsed",
                    key="audio_uploader"
                )
            else:
                audio_file = audio_recorded

            if audio_file:
                st.audio(audio_file)

        st.markdown("<div style='margin: 1.75rem 0;'></div>", unsafe_allow_html=True)

        col_left, col_center, col_right = st.columns([1, 2, 1])
        with col_center:
            analyze_btn = st.button("Analyze Psychological State", type="primary", use_container_width=True)

        if analyze_btn:
            if not text_input or not text_input.strip():
                if not image_file and not audio_file:
                    st.error("Please provide text input, an image, or audio to analyze.")
                    return

            with st.spinner("Processing your analysis..."):
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.012)
                    progress_bar.progress(i + 1)

                result = self.perform_analysis(text_input, image_file, audio_file)
                progress_bar.empty()

                if result:
                    st.session_state.analysis_result = result
                    st.success("Analysis complete")
                    time.sleep(0.6)
                    st.rerun()

    def perform_analysis(self, text: str, image_file, audio_file) -> Dict:
        try:
            # Multimodal analysis (text + image + audio)
            if (image_file or audio_file) and text:
                files = {}
                if image_file:
                    files['image'] = image_file
                if audio_file:
                    files['audio'] = audio_file
                data = {'text': text, 'user_id': st.session_state.user_id}
                response = requests.post(f"{API_BASE_URL}/analysis/multimodal", files=files, data=data, timeout=60)
            # Image or audio only
            elif image_file or audio_file:
                files = {}
                if image_file:
                    files['image'] = image_file
                if audio_file:
                    files['audio'] = audio_file
                data = {'user_id': st.session_state.user_id}
                response = requests.post(f"{API_BASE_URL}/analysis/multimodal", files=files, data=data, timeout=60)
            # Text only
            else:
                data = {'text': text, 'user_id': st.session_state.user_id}
                response = requests.post(f"{API_BASE_URL}/analysis/text", json=data, timeout=60)

            if response.status_code == 200:
                return response.json()
            else:
                st.error(f"Analysis failed: {response.json().get('error', 'Unknown error')}")
                return None
        except Exception as e:
            st.error(f"Error: {str(e)}")
            return None

    def render_premium_card(self, title: str, icon: str, content: str):
        # Build the card HTML - ensure content is clean
        card_html = f"""
        <div class="result-card">
            <h3 class="card-title">{icon} {title}</h3>
            {content.strip()}
        </div>
        """
        st.markdown(card_html, unsafe_allow_html=True)

    def render_results(self, result: Dict):
        st.markdown("""
        <div style="
            background: rgba(79, 209, 197, 0.05);
            border: 1px solid rgba(79, 209, 197, 0.15);
            backdrop-filter: blur(60px);
            padding: 2.25rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            text-align: center;
        ">
            <h2 style="
                margin: 0 0 0.375rem 0;
                font-size: 2.25rem;
                font-weight: 800;
                background: linear-gradient(135deg, #4fd1c5 0%, #8b5cf6 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                letter-spacing: -0.03em;
            ">Psychological Analysis Report</h2>
            <p style="margin: 0; color: #9ca3af; font-size: 1rem;">
                Comprehensive insights based on advanced AI analysis
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Summary
        if result.get('psychological_summary'):
            summary = result['psychological_summary']

            # Get the mental state description (backend returns this field)
            description = summary.get('mental_state_description', 'No summary available')
            emotional_state = summary.get('emotional_state', '')
            stress_level = summary.get('stress_level', '')

            # Render directly with st.markdown to avoid HTML escaping issues
            st.markdown(f"""
            <div class="result-card">
                <h3 class="card-title">🧠 Overview</h3>
                <div style="
                    background: rgba(79, 209, 197, 0.04);
                    padding: 1.5rem;
                    border-radius: 14px;
                    border-left: 3px solid #4fd1c5;
                ">
                    <p style="
                        margin: 0;
                        color: #d1d5db;
                        font-size: 1.0625rem;
                        line-height: 1.6;
                    ">
                        {f'<strong>Emotional State:</strong> {emotional_state}<br><br>' if emotional_state else ''}
                        {description}
                        {f'<br><br><strong>Stress Level:</strong> {stress_level}' if stress_level else ''}
                    </p>
                </div>
            </div>
            """, unsafe_allow_html=True)

        # Emotions and Risk
        col1, col2 = st.columns([2.5, 1], gap="large")

        with col1:
            if result.get('emotions'):
                self.render_emotions(result['emotions'])

        with col2:
            if result.get('risk_assessment'):
                self.render_risk(result['risk_assessment'])

        # Sentiment
        if result.get('sentiment'):
            self.render_sentiment(result['sentiment'])

        # Cognitive
        if result.get('cognitive_distortions'):
            self.render_cognitive(result['cognitive_distortions'])

        # Disorders
        if result.get('disorder_patterns'):
            self.render_disorders(result['disorder_patterns'])

        # Grounding
        if result.get('grounding_techniques'):
            self.render_grounding(result['grounding_techniques'])

        # Recommendations
        if result.get('recommendations'):
            self.render_recommendations(result['recommendations'])

        # Crisis
        if result.get('risk_assessment'):
            risk_level = result['risk_assessment'].get('overall_risk_level', 'minimal')
            if risk_level in ['elevated', 'moderate', 'severe']:
                self.render_crisis()

        # New Analysis
        st.markdown("<div style='margin: 2rem 0;'></div>", unsafe_allow_html=True)
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("Start New Analysis", type="primary", use_container_width=True):
                st.session_state.analysis_result = None
                st.rerun()

    def render_emotions(self, emotions: Dict):
        # Handle both dict and list formats from backend
        if isinstance(emotions, list):
            # Backend returned list format - skip for now
            return

        emotion_data = emotions.get('emotion_distribution', {})
        if not emotion_data:
            return

        labels = list(emotion_data.keys())
        values = list(emotion_data.values())

        colors = {
            'joy': '#10b981',
            'sadness': '#3b82f6',
            'anger': '#ef4444',
            'fear': '#f59e0b',
            'surprise': '#a855f7',
            'disgust': '#ec4899',
            'neutral': '#6b7280'
        }

        emotion_colors = [colors.get(e.lower(), '#6366f1') for e in labels]

        fig = go.Figure(data=[
            go.Bar(
                x=values,
                y=labels,
                orientation='h',
                marker=dict(
                    color=emotion_colors,
                    line=dict(color='rgba(26, 29, 41, 0.3)', width=1)
                ),
                text=[f"{v:.1f}%" for v in values],
                textposition='outside',
                textfont=dict(size=13, color='#d1d5db', weight=600),
                hovertemplate='<b>%{y}</b><br>%{x:.1f}%<extra></extra>'
            )
        ])

        fig.update_layout(
            title=dict(
                text="<b>Emotional Distribution</b>",
                font=dict(size=18, color='#f3f4f6')
            ),
            xaxis_title="Intensity (%)",
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(size=13, color='#9ca3af'),
            height=380,
            margin=dict(l=20, r=80, t=50, b=40),
            xaxis=dict(
                showgrid=True,
                gridcolor='rgba(99, 102, 241, 0.1)',
                range=[0, max(values) * 1.15],
                color='#9ca3af'
            ),
            yaxis=dict(
                showgrid=False,
                color='#d1d5db'
            )
        )

        primary_emotion = emotions.get('primary_emotion', 'N/A').title()
        primary_color = colors.get(emotions.get('primary_emotion', '').lower(), '#6366f1')

        content = f"""
        <div style="margin-bottom: 1.5rem; text-align: center;">
            <div style="
                display: inline-block;
                background: {primary_color};
                color: white;
                padding: 0.75rem 1.5rem;
                border-radius: 10px;
                font-weight: 700;
                font-size: 1.125rem;
            ">
                Primary Emotion: {primary_emotion}
            </div>
        </div>
        """

        self.render_premium_card("Emotional Analysis", "🎭", content)
        st.plotly_chart(fig, use_container_width=True)

    def render_risk(self, risk: Dict):
        risk_level = risk.get('overall_risk_level', 'minimal')
        risk_colors = {
            'minimal': '#10b981',
            'low': '#3b82f6',
            'moderate': '#f59e0b',
            'elevated': '#ef4444',
            'severe': '#991b1b'
        }
        risk_icons = {
            'minimal': '✅',
            'low': '🟢',
            'moderate': '🟡',
            'elevated': '🟠',
            'severe': '🔴'
        }

        color = risk_colors.get(risk_level, '#6b7280')
        icon = risk_icons.get(risk_level, '⚪')
        rationale = risk.get('rationale', 'Assessment based on indicators')

        # Render directly to avoid HTML escaping issues
        st.markdown(f"""
        <div class="result-card">
            <h3 class="card-title">🎯 Risk Level</h3>
            <div style="text-align: center;">
                <div style="
                    background: {color}15;
                    border: 2px solid {color};
                    border-radius: 12px;
                    padding: 2rem;
                    margin-bottom: 1rem;
                ">
                    <div style="font-size: 3rem; margin-bottom: 0.5rem;">{icon}</div>
                    <div style="
                        font-size: 1.5rem;
                        font-weight: 800;
                        color: {color};
                        text-transform: uppercase;
                        letter-spacing: 0.05em;
                    ">{risk_level}</div>
                </div>
                <p style="color: #9ca3af; font-size: 0.9375rem; line-height: 1.6;">
                    {rationale}
                </p>
            </div>
        </div>
        """, unsafe_allow_html=True)

    def render_sentiment(self, sentiment: Dict):
        score = sentiment.get('score', 0)
        label = sentiment.get('label', 'neutral')
        normalized_score = ((score + 1) / 2) * 100

        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=normalized_score,
            title={'text': "<b>Sentiment Score</b>", 'font': {'size': 18, 'color': '#f3f4f6'}},
            number={'font': {'size': 42, 'color': '#818cf8'}},
            gauge={
                'axis': {'range': [0, 100], 'color': '#6b7280'},
                'bar': {'color': "#6366f1", 'thickness': 0.75},
                'bgcolor': "rgba(30, 33, 45, 0.5)",
                'borderwidth': 0,
                'steps': [
                    {'range': [0, 33], 'color': 'rgba(239, 68, 68, 0.15)'},
                    {'range': [33, 66], 'color': 'rgba(245, 158, 11, 0.15)'},
                    {'range': [66, 100], 'color': 'rgba(16, 185, 129, 0.15)'}
                ]
            }
        ))

        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            font={'color': "#9ca3af"},
            height=300,
            margin=dict(l=20, r=20, t=60, b=20)
        )

        content = f"""
        <div style="text-align: center; margin-bottom: 1.5rem;">
            <span style="
                display: inline-block;
                background: linear-gradient(135deg, #6366f1, #a855f7);
                color: white;
                padding: 0.625rem 1.5rem;
                border-radius: 10px;
                font-weight: 700;
                font-size: 1rem;
            ">{label.title()}</span>
        </div>
        """

        self.render_premium_card("Sentiment Analysis", "💭", content)
        st.plotly_chart(fig, use_container_width=True)

    def render_cognitive(self, cognitive: Dict):
        distortions = cognitive.get('detected_distortions', [])

        if not distortions:
            content = """
            <div style="text-align: center; padding: 2rem;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">✅</div>
                <p style="color: #10b981; font-size: 1.125rem; font-weight: 700;">
                    No Cognitive Distortions Detected
                </p>
                <p style="color: #6b7280; font-size: 0.9375rem;">
                    Thought patterns appear balanced
                </p>
            </div>
            """
        else:
            distortion_items = ""
            for dist in distortions:
                distortion_items += f"""
                <div style="
                    background: rgba(239, 68, 68, 0.08);
                    border-left: 3px solid #ef4444;
                    padding: 1.25rem;
                    border-radius: 10px;
                    margin-bottom: 1rem;
                ">
                    <div style="color: #fca5a5; font-weight: 700; font-size: 1.0625rem; margin-bottom: 0.5rem;">
                        {dist.get('type', 'Unknown')}
                    </div>
                    <div style="color: #d1d5db; font-size: 0.9375rem; line-height: 1.6; margin-bottom: 0.5rem;">
                        {dist.get('description', '')}
                    </div>
                    <div style="color: #9ca3af; font-size: 0.875rem; font-style: italic;">
                        Example: "{dist.get('example', '')}"
                    </div>
                </div>
                """
            content = distortion_items

        self.render_premium_card("Cognitive Patterns", "🧩", content)

    def render_disorders(self, disorders):
        if not disorders:
            return

        # Start card
        st.markdown('<div class="result-card"><h3 class="card-title">🔍 Pattern Analysis</h3>', unsafe_allow_html=True)

        # Handle both list and dict formats
        if isinstance(disorders, list):
            # Backend returned list format
            for item in disorders:
                if isinstance(item, dict):
                    # Backend uses 'pattern_name' and 'confidence'
                    pattern_name = item.get('pattern_name', item.get('disorder', 'Unknown Pattern'))
                    confidence = item.get('confidence', item.get('likelihood', 0))
                    indicators = item.get('indicators', [])
                    explanation = item.get('explanation', '')

                    # Convert confidence to percentage (0-1 to 0-100)
                    likelihood = int(confidence * 100) if confidence <= 1 else int(confidence)

                    if likelihood > 0:
                        color = '#ef4444' if likelihood > 70 else '#f59e0b' if likelihood > 40 else '#3b82f6'

                        indicators_html = "".join([f"<li style='color: #d1d5db; margin-bottom: 0.5rem; font-size: 0.9375rem;'>{ind}</li>" for ind in indicators[:5]])

                        st.markdown(f"""
                        <div style="margin-bottom: 1.5rem; padding: 1.5rem; background: rgba(30, 33, 45, 0.5); border-radius: 12px; border-left: 3px solid {color};">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                <h4 style="margin: 0; color: #4fd1c5; font-size: 1.125rem; font-weight: 600;">{pattern_name}</h4>
                                <span style="color: {color}; font-weight: 700; font-size: 1rem;">{likelihood}%</span>
                            </div>
                            {f'<p style="color: #9ca3af; font-size: 0.9375rem; margin-bottom: 1rem; font-style: italic;">{explanation}</p>' if explanation else ''}
                            {f'<ul style="margin: 0; padding-left: 1.5rem;">{indicators_html}</ul>' if indicators else ''}
                        </div>
                        """, unsafe_allow_html=True)
        else:
            # Dict format (original code)
            for disorder, data in disorders.items():
                if isinstance(data, dict):
                    likelihood = data.get('likelihood', 0)
                    indicators = data.get('indicators', [])

                    if likelihood > 0:
                        color = '#ef4444' if likelihood > 70 else '#f59e0b' if likelihood > 40 else '#3b82f6'

                        indicators_html = "".join([f"<li style='color: #d1d5db; margin-bottom: 0.5rem; font-size: 0.9375rem;'>{ind}</li>" for ind in indicators[:5]])

                        st.markdown(f"""
                        <div style="
                            background: rgba(30, 33, 45, 0.5);
                            border: 1px solid {color}30;
                            border-radius: 12px;
                            padding: 1.5rem;
                            margin-bottom: 1.25rem;
                        ">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                <h4 style="margin: 0; color: #f3f4f6; font-weight: 700; font-size: 1.125rem;">
                                    {disorder.replace('_', ' ').title()}
                                </h4>
                                <div style="
                                    background: {color};
                                    color: white;
                                    padding: 0.5rem 1rem;
                                    border-radius: 8px;
                                    font-weight: 700;
                                    font-size: 1rem;
                                ">{likelihood}%</div>
                            </div>
                            <div style="
                                background: {color}20;
                                height: 8px;
                                border-radius: 10px;
                                margin-bottom: 1rem;
                                overflow: hidden;
                            ">
                                <div style="
                                    background: {color};
                                    height: 100%;
                                    width: {likelihood}%;
                                    border-radius: 10px;
                                "></div>
                            </div>
                            <ul style="margin: 0; padding-left: 1.25rem;">{indicators_html}</ul>
                        </div>
                        """, unsafe_allow_html=True)

        # End card
        st.markdown('</div>', unsafe_allow_html=True)

    def render_grounding(self, techniques: List):
        if not techniques:
            return

        icons = {
            '5-4-3-2-1': '🔢',
            'box breathing': '🫁',
            'progressive muscle relaxation': '💪',
            'body scan': '🧘',
            'grounding statements': '💬'
        }

        # Start card
        st.markdown('<div class="result-card"><h3 class="card-title">🌿 Grounding Techniques</h3>', unsafe_allow_html=True)

        # Render each technique separately to avoid escaping issues
        for tech in techniques:
            # Backend uses 'technique_name' not 'name'
            name = tech.get('technique_name', tech.get('name', ''))
            description = tech.get('description', '')
            # Backend uses 'steps' (list) not 'instructions' (string)
            steps = tech.get('steps', [])
            when_to_use = tech.get('when_to_use', '')
            icon = icons.get(name.lower(), '✨')

            # Format steps as numbered list
            if steps:
                steps_html = "<ol style='margin: 0; padding-left: 1.5rem; color: #e5e7eb;'>"
                for step in steps:
                    steps_html += f"<li style='margin-bottom: 0.5rem; font-size: 0.9375rem;'>{step}</li>"
                steps_html += "</ol>"
            else:
                steps_html = "<p style='color: #e5e7eb; font-size: 0.9375rem; margin: 0;'>No steps available</p>"

            st.markdown(f"""
            <div style="
                background: rgba(99, 102, 241, 0.05);
                border: 1px solid rgba(99, 102, 241, 0.2);
                border-radius: 12px;
                padding: 1.5rem;
                margin-bottom: 1.25rem;
            ">
                <h4 style="margin: 0 0 0.75rem 0; color: #f3f4f6; font-weight: 700; font-size: 1.0625rem;">
                    {icon} {name}
                </h4>
                <p style="color: #d1d5db; font-size: 0.9375rem; line-height: 1.6; margin-bottom: 1rem;">
                    {description}
                </p>
                <div style="
                    background: rgba(20, 23, 35, 0.5);
                    padding: 1rem;
                    border-radius: 10px;
                    border-left: 3px solid #6366f1;
                ">
                    <div style="color: #818cf8; font-weight: 600; font-size: 0.8125rem; margin-bottom: 0.5rem; text-transform: uppercase;">
                        Steps:
                    </div>
                    {steps_html}
                    {f'<p style="color: #9ca3af; font-size: 0.875rem; margin-top: 0.75rem; font-style: italic;">When to use: {when_to_use}</p>' if when_to_use else ''}
                </div>
            </div>
            """, unsafe_allow_html=True)

        # End card
        st.markdown('</div>', unsafe_allow_html=True)

    def render_recommendations(self, recommendations):
        # Handle both list and dict formats
        if isinstance(recommendations, list):
            # Backend returned list format - skip for now or extract data
            return
        elif isinstance(recommendations, dict):
            books = recommendations.get('books', [])
            routines = recommendations.get('routines', [])
        else:
            return

        if books:
            content = ""
            for book in books[:5]:
                content += f"""
                <div style="
                    background: rgba(30, 33, 45, 0.4);
                    border: 1px solid rgba(99, 102, 241, 0.15);
                    border-radius: 12px;
                    padding: 1.25rem;
                    margin-bottom: 1rem;
                ">
                    <h4 style="margin: 0 0 0.5rem 0; color: #f3f4f6; font-weight: 700; font-size: 1.0625rem;">
                        📚 {book.get('title', '')}
                    </h4>
                    <p style="margin: 0 0 0.5rem 0; color: #818cf8; font-weight: 600; font-size: 0.9375rem;">
                        {book.get('author', '')}
                    </p>
                    <p style="margin: 0; color: #d1d5db; font-size: 0.9375rem; line-height: 1.6;">
                        {book.get('reason', '')}
                    </p>
                </div>
                """

            self.render_premium_card("Recommended Reading", "📖", content)

        if routines:
            content = ""
            for routine in routines:
                content += f"""
                <div style="
                    background: rgba(16, 185, 129, 0.08);
                    border-left: 3px solid #10b981;
                    border-radius: 10px;
                    padding: 1.25rem;
                    margin-bottom: 1rem;
                ">
                    <h4 style="margin: 0 0 0.5rem 0; color: #6ee7b7; font-weight: 700; font-size: 1.0625rem;">
                        ✨ {routine.get('name', '')}
                    </h4>
                    <p style="margin: 0; color: #d1d5db; font-size: 0.9375rem; line-height: 1.6;">
                        {routine.get('description', '')}
                    </p>
                </div>
                """

            self.render_premium_card("Daily Practices", "🌟", content)

    def render_crisis(self):
        content = """
        <div style="
            background: rgba(239, 68, 68, 0.1);
            border: 2px solid #ef4444;
            border-radius: 16px;
            padding: 2.5rem;
            text-align: center;
        ">
            <div style="font-size: 3rem; margin-bottom: 1rem;">🆘</div>
            <h3 style="margin: 0 0 1rem 0; color: #fca5a5; font-weight: 800; font-size: 1.5rem;">
                Immediate Support Available
            </h3>
            <p style="color: #d1d5db; font-size: 1rem; line-height: 1.6; margin: 0 0 2rem 0;">
                If you're in crisis, reach out immediately. Help is available 24/7.
            </p>
            <div style="
                background: rgba(20, 23, 35, 0.6);
                border-radius: 12px;
                padding: 2rem;
            ">
                <h4 style="margin: 0 0 1.25rem 0; color: #f3f4f6; font-weight: 700; font-size: 1.125rem;">
                    24/7 Crisis Hotlines
                </h4>
                <div style="display: grid; gap: 1rem; text-align: left;">
                    <div style="
                        background: rgba(239, 68, 68, 0.08);
                        padding: 1rem;
                        border-radius: 10px;
                        border-left: 3px solid #ef4444;
                    ">
                        <div style="font-weight: 600; color: #fca5a5; margin-bottom: 0.25rem; font-size: 0.9375rem;">
                            🇺🇸 US Suicide Prevention
                        </div>
                        <div style="font-size: 1.5rem; font-weight: 800; color: #818cf8;">988</div>
                    </div>
                    <div style="
                        background: rgba(239, 68, 68, 0.08);
                        padding: 1rem;
                        border-radius: 10px;
                        border-left: 3px solid #ef4444;
                    ">
                        <div style="font-weight: 600; color: #fca5a5; margin-bottom: 0.25rem; font-size: 0.9375rem;">
                            🇬🇧 UK Samaritans
                        </div>
                        <div style="font-size: 1.5rem; font-weight: 800; color: #818cf8;">116 123</div>
                    </div>
                </div>
            </div>
        </div>
        """
        st.markdown(content, unsafe_allow_html=True)

    def run(self):
        self.render_header()
        self.render_input_section()

        if st.session_state.analysis_result:
            self.render_results(st.session_state.analysis_result)

if __name__ == "__main__":
    app = MindScopeAI()
    app.run()
