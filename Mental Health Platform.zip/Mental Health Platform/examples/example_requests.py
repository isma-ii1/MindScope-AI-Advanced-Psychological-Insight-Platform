"""
Example API requests for MindScope AI
"""

import requests
import json
from pathlib import Path

API_BASE_URL = "http://localhost:5000/api"

def example_text_analysis_anxiety():
    """Example: Analyze text with anxiety patterns"""
    print("\n=== Example 1: Anxiety Analysis ===")

    data = {
        "text": "I'm so anxious all the time. I can't stop worrying about everything. What if something terrible happens? I feel like I'm always on edge and can't relax.",
        "user_id": "example_user_1"
    }

    response = requests.post(f"{API_BASE_URL}/analysis/text", json=data)

    if response.status_code == 200:
        result = response.json()
        print(f"Analysis ID: {result['analysis_id']}")
        print(f"Primary Emotion: {result['emotions'][0]['emotion']} ({result['emotions'][0]['score']:.2f})")
        print(f"Risk Level: {result['risk_assessment']['overall_risk_level']}")
        print(f"Detected Patterns: {[p['pattern_name'] for p in result['disorder_patterns'][:3]]}")
        print(f"Cognitive Distortions: {[d['distortion_type'] for d in result['cognitive_distortions'][:3]]}")
    else:
        print(f"Error: {response.json()}")

def example_text_analysis_depression():
    """Example: Analyze text with depressive patterns"""
    print("\n=== Example 2: Depression Analysis ===")

    data = {
        "text": "I feel so empty and numb. Nothing brings me joy anymore. I have no energy to do anything. I just want to sleep all day. Everything feels hopeless.",
        "user_id": "example_user_2"
    }

    response = requests.post(f"{API_BASE_URL}/analysis/text", json=data)

    if response.status_code == 200:
        result = response.json()
        print(f"Analysis ID: {result['analysis_id']}")
        print(f"Emotional State: {result['psychological_summary']['emotional_state']}")
        print(f"Stress Level: {result['psychological_summary']['stress_level']}")
        print(f"Key Insights: {result['psychological_summary']['key_insights'][:2]}")
    else:
        print(f"Error: {response.json()}")

def example_text_analysis_ocd():
    """Example: Analyze text with OCD patterns"""
    print("\n=== Example 3: OCD Pattern Analysis ===")

    data = {
        "text": "I have these intrusive thoughts that won't go away. I keep checking things over and over again. I must make sure everything is perfect or something bad will happen. I can't stop these compulsions.",
        "user_id": "example_user_3"
    }

    response = requests.post(f"{API_BASE_URL}/analysis/text", json=data)

    if response.status_code == 200:
        result = response.json()
        print(f"Analysis ID: {result['analysis_id']}")
        print(f"Detected Patterns: {json.dumps([p['pattern_name'] for p in result['disorder_patterns']], indent=2)}")
        print(f"Recommended Grounding Techniques:")
        for technique in result['grounding_techniques'][:2]:
            print(f"  - {technique['technique_name']}: {technique['description']}")
    else:
        print(f"Error: {response.json()}")

def example_text_analysis_risk():
    """Example: Analyze text with elevated risk indicators"""
    print("\n=== Example 4: Risk Assessment (Elevated) ===")

    data = {
        "text": "I feel so hopeless. Nothing matters anymore. I don't see any way out of this darkness. I'm a burden to everyone.",
        "user_id": "example_user_4"
    }

    response = requests.post(f"{API_BASE_URL}/analysis/text", json=data)

    if response.status_code == 200:
        result = response.json()
        print(f"Analysis ID: {result['analysis_id']}")
        print(f"Risk Level: {result['risk_assessment']['overall_risk_level']}")
        print(f"Risk Score: {result['risk_assessment']['risk_score']:.2f}")
        print(f"Explanation: {result['risk_assessment']['explanation']}")
        print(f"Recommended Action: {result['risk_assessment']['recommended_action']}")
        print(f"Grounding Techniques Provided: {len(result['grounding_techniques'])}")
    else:
        print(f"Error: {response.json()}")

def example_multimodal_analysis():
    """Example: Analyze text + image (requires image file)"""
    print("\n=== Example 5: Multimodal Analysis ===")

    # This requires an actual image file
    # For demonstration, we'll show the structure
    print("Note: This example requires an image file to work.")
    print("Structure:")
    print("""
    files = {'image': open('path/to/image.jpg', 'rb')}
    data = {
        'text': 'Feeling isolated today...',
        'user_id': 'example_user_5'
    }
    response = requests.post(f"{API_BASE_URL}/analysis/multimodal", files=files, data=data)
    """)

def example_get_history():
    """Example: Retrieve user history"""
    print("\n=== Example 6: Get User History ===")

    user_id = "example_user_1"
    response = requests.get(f"{API_BASE_URL}/analysis/history/{user_id}?limit=5")

    if response.status_code == 200:
        result = response.json()
        print(f"User: {result['user_id']}")
        print(f"Total analyses in history: {result['count']}")
        for i, analysis in enumerate(result['history'], 1):
            print(f"\n  Analysis {i}:")
            print(f"    ID: {analysis['_id']}")
            print(f"    Created: {analysis.get('created_at', 'N/A')}")
    else:
        print(f"Error: {response.json()}")

def example_health_checks():
    """Example: Health check endpoints"""
    print("\n=== Example 7: Health Checks ===")

    # Ping
    response = requests.get(f"{API_BASE_URL}/health/ping")
    print(f"API Status: {response.json()}")

    # Database
    response = requests.get(f"{API_BASE_URL}/health/db")
    print(f"Database Status: {response.json()}")

def run_all_examples():
    """Run all example requests"""
    print("=" * 60)
    print("MindScope AI - API Examples")
    print("=" * 60)

    try:
        example_health_checks()
        example_text_analysis_anxiety()
        example_text_analysis_depression()
        example_text_analysis_ocd()
        example_text_analysis_risk()
        example_multimodal_analysis()
        example_get_history()

        print("\n" + "=" * 60)
        print("All examples completed!")
        print("=" * 60)

    except requests.exceptions.ConnectionError:
        print("\nError: Cannot connect to API. Make sure the backend is running on http://localhost:5000")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    run_all_examples()
